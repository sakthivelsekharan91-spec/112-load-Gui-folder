export FLASK_APP=/opt/product/LOAD_GUI/bin/flaskr/flaskr.py
export FLASK_DEBUG=true
export FLASK_CONFIG="/opt/product/LOAD_GUI/DATA_LINUX_LOAD/config.py"
flask run --host='192.168.151.112' --port=6003
