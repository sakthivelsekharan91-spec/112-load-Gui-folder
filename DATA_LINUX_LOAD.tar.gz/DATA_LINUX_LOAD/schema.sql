drop table if exists entries;
drop table if exists dblists;
drop table if exists loadqueries;

create table entries (
  id integer primary key autoincrement,
  title text not null,
  'text' text not null
);

create table dblists (
  id integer primary key autoincrement,
  alias text unique,
  db_type text not null,
  username text not null,
  password text not null,
  ip_address text not null,
  service_name text
);

create table loadqueries (
  id integer primary key autoincrement,
  load_alias text unique,
  dbqueries text not null
);
