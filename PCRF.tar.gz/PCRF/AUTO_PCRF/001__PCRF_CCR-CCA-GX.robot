*** Settings ***
Documentation     PCRF_CCR_CCA_GX_TEST_SUITE
Suite Setup       SUITE STARTUP
Test teardown     TEST STOP
Force Tags        PCRF_CCR_CCA_GX
Default Tags      P2
Test Timeout      5 minutes
Library           Collections
Library           SSHLibrary
Library           OperatingSystem
Library           String
Library           BuiltIn
Library           DateTime
Library           DatabaseLibrary
Library           XML
Library           Rammbock
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_MGTS_CONNECT.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_START_STOP.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_APP_CONNECT.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_SEAGULL_RUN.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_DB_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_LOGGING.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_CDR_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_SUITE_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_PCAP_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_SHELL_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_REMOTE_APP.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_TESTCASE_MODULE.robot
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_MAIN_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_LOGGING_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_CDR_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_DB_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_SEAGULL_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_PCAP_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_SHELL_COMMAND_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_REMOTE_APP_DETAILS.py


*** Variables ***
${LOGGER_Validation}               1
${CDR_Validation}                  0
${PRE_DB_Validation}               1
${POST_DB_QUERY_Validation}        0
${SHELL_ON_CALL_CMD}               1




*** Test Cases ***

PCRF_AUTO_001
    [Documentation]    "To Verify CCA response AVPs and AVP values received from PCRF for CCR Initial request sent from GGSN."
    [Tags]    CRIT_P1_PCRF_CCR_CCA_GX
    Set Test Variable    ${SHELL_PRE_CMD}       1
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_002
    [Documentation]    "To Verify CCA response AVPs and AVP values received from PCRF for CCR Initial request when SPR Authorized QoS is greater than Requested QoS and RAT Type is not enabled in PCRF for received RAT Type from GGSN ."
    [Tags]    CRIT_P1_PCRF_CCR_CCA_GX
    DEPENDANT    PCRF_AUTO_001    1,0,1,0,0,1,0,1,0,0
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_003
    [Documentation]    " To Verify CCA response AVPs and AVP values received from PCRF for CCR Initial request when SPR Authorized QoS is greater than Requested QoS and RAT Type is enabled in PCRF for received RAT Type from GGSN."
    [Tags]    P1_PCRF_CCR_CCA_GX
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_004
    [Documentation]    "To Verify CCA response AVPs and AVP values received from PCRF for CCR Update request sent from GGSN due to RAT Change."
    [Tags]    P1_PCRF_CCR_CCA_GX
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_005
    [Documentation]    "To Verify CCA response AVPs and AVP values received from PCRF for CCR Update request sent from GGSN due to RAT Change when SPR authorized QoS is greater than Requested QoS received in CCR-U and RAT Type is enabled in PCRF for received RAT Type."
    [Tags]    P1_PCRF_CCR_CCA_GX
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_006
    [Documentation]    "To Verify CCA response AVPs and AVP values received from PCRF for CCR Update request sent from GGSN due to QoS Change "
    [Tags]    P1_PCRF_CCR_CCA_GX
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_007
    [Documentation]    "To Verify CCA response AVPs and AVP values received from PCRF when QoS Information AVP is not sent in CCR-Update Request "
    [Tags]    P1_PCRF_CCR_CCA_GX
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_008
    [Documentation]    "To Verify CCA response AVPs and AVP values received from PCRF when RAT Type AVP is not sent in CCR-Update Request "
    [Tags]    P2_PCRF_CCR_CCA_GX
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_009
    [Documentation]    "To Verify CCA response AVPs and AVP values received from PCRF when Default EPS Bearer AVP is not sent in CCR-Update Request "
    [Tags]    P2_PCRF_CCR_CCA_GX
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_010
    [Documentation]    "To Verify CCA response AVPs and AVP values received from PCRF when Multiple CCR-Update Request is received from GGSN "
    [Tags]    P2_PCRF_CCR_CCA_GX
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

*** Keywords ***
