*** Settings ***
Documentation     PCRF_BUNDLE_SPECIFIC_CCR_CCA_GX_TEST_SUITE
Suite Setup       SUITE STARTUP
Test teardown     TEST STOP
Force Tags        BUNDLE_SPECIFIC_CCR_CCA_GX
Default Tags      P2
Test Timeout      5 minutes
Library           Collections
Library           SSHLibrary
Library           OperatingSystem
Library           String
Library           BuiltIn
Library           DateTime
Library           DatabaseLibrary
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_MGTS_CONNECT.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_START_STOP.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_APP_CONNECT.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_SEAGULL_RUN.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_DB_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_LOGGING.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_CDR_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_SUITE_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_PCAP_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_SHELL_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_REMOTE_APP.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_TESTCASE_MODULE.robot
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_MAIN_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_LOGGING_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_CDR_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_DB_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_SEAGULL_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_PCAP_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_SHELL_COMMAND_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_REMOTE_APP_DETAILS.py

*** Variables ***
${LOGGER_Validation}           1
${CDR_Validation}              0
${DB_Validation}               1
${POST_DB_QUERY_Validation}    0

*** Test Cases ***
PCRF_AUTO_011
    [Documentation]    "To verify PCRF CCR-I Response contains proper QOS & SDF data, when subscriber has only Bundle not mapped to PCRF"
    [Tags]    CRIT_P1_BUNDLE_SPECIFIC_CCR_CCA_GX
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_012
    [Documentation]    "To verify PCRF CCR-I Response contains proper QOS & SDF data, when subscriber has only Bundle not mapped to PCRF & Free Data left is equal to MIN_ACCEPTED_BYTES_LIMIT ."
    [Tags]    P1_BUNDLE_SPECIFIC_CCR_CCA_GX
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_013
    [Documentation]    "To verify PCRF CCR-I Response contains proper QOS & SDF data, when subscriber has only Bundle not mapped to PCRF & Free Data is exhausted."
    [Tags]    CRIT_P1_BUNDLE_SPECIFIC_CCR_CCA_GX
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_014
    [Documentation]    "To verify PCRF CCR-I Response contains proper QOS & SDF data, when subscriber has only Top-Up Free Data not mapped to PCRF."
    [Tags]    P1_BUNDLE_SPECIFIC_CCR_CCA_GX
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_015
    [Documentation]    To verify PCRF CCR-I Response contains proper QOS & SDF data, when subscriber has only Top-Up Free Data not mapped to PCRF & Free Data left is equal to MIN_ACCEPTED_BYTES_LIMIT ."
    [Tags]    P2_BUNDLE_SPECIFIC_CCR_CCA_GX
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_016
    [Documentation]    "To verify PCRF CCR-I Response contains proper QOS & SDF data, when subscriber has only Bundle not mapped to PCRF & Free Data is exhausted."
    [Tags]    P2_BUNDLE_SPECIFIC_CCR_CCA_GX
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_017
    [Documentation]    "To verify PCRF CCR-I Response contains proper QOS & SDF data, when subscriber usage starts with Max CAP of Bundle."
    [Tags]    P1_BUNDLE_SPECIFIC_CCR_CCA_GX
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_018
    [Documentation]    "To verify PCRF CCR-I Response contains proper QOS & SDF data, when subscriber usage starts with After CAP amount of Bundle after his Bundle free data Max Cap exhaust case."
    [Tags]    P2_BUNDLE_SPECIFIC_CCR_CCA_GX
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_019
    [Documentation]    "To verify PCRF CCR-I Response contains proper QOS & SDF data, when subscriber usage starts with After Cap amount after his Bundle free data left out is equal to MIN_ACCEPTED_BYTES_LIMIT."
    [Tags]    P2_BUNDLE_SPECIFIC_CCR_CCA_GX
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_020
    [Documentation]    "To verify PCRF CCR-I Response contains proper QOS & SDF data, when subscriber usage starts with Standard Tariff after his Bundle Free Data Left & After CAP amount configured exhausted ."
    [Tags]    P2_BUNDLE_SPECIFIC_CCR_CCA_GX
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_021
    [Documentation]    "To verify PCRF CCR-I Response contains proper QOS & SDF data, when subscriber usage starts with Standard Tariff after After CAP amount is exhausted & Bundle Free Data Left is equal to Min_Accepted_Bytes_Limit."
    [Tags]    P2_BUNDLE_SPECIFIC_CCR_CCA_GX
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_022
    [Documentation]    "To verify PCRF CCR-I Response contains proper QOS & SDF data, when subscriber usage starts with Standard Tariff after Bundle is expired ."
    [Tags]    P2_BUNDLE_SPECIFIC_CCR_CCA_GX
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_023
    [Documentation]    "To verify PCRF CCR-I Response contains proper QOS & SDF data, when subscriber initiate data session after Bundle auto-renewal ."
    [Tags]    P2_BUNDLE_SPECIFIC_CCR_CCA_GX
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_024
    [Documentation]    "To verify PCRF CCR-I Response contains proper QOS & SDF data, when subscriber done the same over-written bundle top-up before expiry of the bundle ."
    [Tags]    P2_BUNDLE_SPECIFIC_CCR_CCA_GX
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_025
    [Documentation]    "To verify PCRF CCR-I Response contains proper QOS & SDF data, when subscriber done the same normal bundle top-up before expiry of the bundle(Bundle Counter Validation) ."
    [Tags]    P2_BUNDLE_SPECIFIC_CCR_CCA_GX
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_026
    [Documentation]    "To verify PCRF CCR-I Response contains proper QOS & SDF data, when subscriber bundle free data left is equal to MIN_ACCEPTED_BYTES_LIMIT & Transaction Details is not get updated properly in Transaction Table ."
    [Tags]    P2_BUNDLE_SPECIFIC_CCR_CCA_GX
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_027
    [Documentation]    "To verify PCRF CCR-I Negative Response, when subscriber Bundle Free Data Left & After CAP amount configured is exhausted & After CAP action flag is configured as Barring ."
    [Tags]    P2_BUNDLE_SPECIFIC_CCR_CCA_GX
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

*** Keywords ***
