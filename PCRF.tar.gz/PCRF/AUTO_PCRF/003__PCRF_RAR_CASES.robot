*** Settings ***
Documentation     PCRF_RAR_TEST_SUITE
Suite Setup       SUITE STARTUP
Test teardown     TEST STOP
Force Tags        RAR
Default Tags      P2
Test Timeout      5 minutes
Library           Collections
Library           SSHLibrary
Library           OperatingSystem
Library           String
Library           BuiltIn
Library           DateTime
Library           DatabaseLibrary
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_MGTS_CONNECT.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_START_STOP.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_APP_CONNECT.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_SEAGULL_RUN.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_DB_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_LOGGING.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_CDR_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_SUITE_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_PCAP_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_SHELL_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_REMOTE_APP.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_TESTCASE_MODULE.robot
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_MAIN_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_LOGGING_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_CDR_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_DB_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_SEAGULL_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_PCAP_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_SHELL_COMMAND_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_REMOTE_APP_DETAILS.py


*** Variables ***


*** Test Cases ***
PCRF_AUTO_028
    [Documentation]    "To verify RAR contains proper QoS & SDF Data when subscriber switches from Max CAP of Unlimited Bundle to Continue Free ."
    [Tags]    CRIT_P1_RAR
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_029
    [Documentation]    "To verify PCRF CCR-I Response contains proper QoS & SDF Data when subscriber data session starts with After CAP of Unlimited Bundle ."
    [Tags]    P1_RAR
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_030
    [Documentation]    "To verify RAR contains proper QoS & SDF Data when subscriber switches from max CAP of normal bundle to After CAP of normal bundle to Standard Tariff ."
    [Tags]    CRIT_RAR_FAIL
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_031
    [Documentation]    "To verify RAR contains proper QoS & SDF Data when subscriber switches from Max CAP of Unlimited Top-Up Free Data to Continue Free."
    [Tags]    P1_RAR
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_032
    [Documentation]    "To verify PCRF CCR-I Response contains proper QoS & SDF Data when subscriber data session starts with After CAP of Unlimited Top-Up Free Data "
    [Tags]    P2_RAR
    Sleep    60s
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_033
    [Documentation]    "To verify RAR contains proper QoS & SDF Data when subscriber switches from max CAP of normal Top-Up Free Data to After CAP of Top-Up Free Data to Standard Tariff ."
    [Tags]    P2_RAR_FAIL
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_034
    [Documentation]    "To verify PCRF CCR-I response & RAR contains proper QOS & SDF data when data session switches from Limited Bundle to Standard Tariff wihere PCRF is not attached to Limited Bundle ."
    [Tags]    P1_RAR
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_035
    [Documentation]    "To verify PCRF CCR-I response & RAR contains proper QOS & SDF data when data session switches from Limited Bundle to Standard Tariff wihere PCRF attached to Limited Bundle ."
    [Tags]    P2_RAR
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_036
    [Documentation]    "To verify PCRF CCR-I response & RAR contains proper QOS & SDF data when data session switches from Limited Top-Up Free Data to Standard Tariff where PCRF is not attached to Top-Up Free Data ."
    [Tags]    P2_RAR
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_037
    [Documentation]    "To verify PCRF CCR-I response & RAR contains proper QOS & SDF data when data session switches from Limited Top-Up Free Data to Standard Tariff where PCRF is attached to Top-Up Free Data ."
    [Tags]    P2_RAR
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_038
    [Documentation]    "To verify PCRF CCR-I response contains proper QoS & SDF Data when Limited Bundle exhausts & data session starts with Standard Tariff ."
    [Tags]    P2_RAR
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_039
    [Documentation]    "To verify PCRF CCR-I response contains proper QoS & SDF Data when Limited Top-Up Free data exhausts & data session starts with Standard Tariff ."
    [Tags]    P2_RAR
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

*** Keywords ***
