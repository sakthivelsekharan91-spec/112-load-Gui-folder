*** Settings ***
Documentation     PCRF_TOP-UP_FREE_SPECIFIC_CCR-CCA-GX_TEST_SUITE
Suite Setup       SUITE STARTUP
Test teardown     TEST STOP
Force Tags        TOP-UP_FREE_SPECIFIC_CCR-CCA-GX
Default Tags      P2
Test Timeout      5 minutes
Library           Collections
Library           SSHLibrary
Library           OperatingSystem
Library           String
Library           BuiltIn
Library           DateTime
Library           DatabaseLibrary
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_MGTS_CONNECT.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_START_STOP.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_APP_CONNECT.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_SEAGULL_RUN.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_DB_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_LOGGING.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_CDR_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_SUITE_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_PCAP_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_SHELL_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_REMOTE_APP.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_TESTCASE_MODULE.robot
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_MAIN_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_LOGGING_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_CDR_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_DB_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_SEAGULL_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_PCAP_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_SHELL_COMMAND_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_REMOTE_APP_DETAILS.py

*** Variables ***
${LOGGER_Validation}           1
${CDR_Validation}              0
${DB_Validation}               1
${POST_DB_QUERY_Validation}    0

*** Test Cases ***
PCRF_AUTO_040
    [Documentation]    "To verify PCRF CCR-I Response contains proper QOS & SDF data, when subscriber usage starts with Max CAP of Only Top-Up Free Data ."
    [Tags]    CRIT_P1_TOP-UP_FREE_SPECIFIC_CCR-CCA-GX
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_041
    [Documentation]    "To verify PCRF CCR-I Response contains proper QOS & SDF data, when subscriber usage starts with After CAP amount of Top-Up Free Data after his only Top-Up free data Max Cap exhaust case ."
    [Tags]    P1_TOP-UP_FREE_SPECIFIC_CCR-CCA-GX
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_042
    [Documentation]    "To verify PCRF CCR-I Response contains proper QOS & SDF data, when subscriber usage starts with After CAP amount of Top-Up Free Data after his only Top-Up free data left out is equal to MIN_ACCEPTED_BYTES_LIMIT ."
    [Tags]    P1_TOP-UP_FREE_SPECIFIC_CCR-CCA-GX
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_043
    [Documentation]    "To verify PCRF CCR-I Response contains proper QOS & SDF data, when subscriber usage starts with Standard Tariff after his only Top-Up Free Data Left & After CAP amount configured exhausted ."
    [Tags]    P1_TOP-UP_FREE_SPECIFIC_CCR-CCA-GX
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_044
    [Documentation]    "To verify PCRF CCR-I Response contains proper QOS & SDF data, when subscriber usage starts with Standard Tariff after After CAP amount is exhausted & Top-Up Free Data Left is equal to Min_Accepted_Bytes_Limit ."
    [Tags]    P1_TOP-UP_FREE_SPECIFIC_CCR-CCA-GX
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_045
    [Documentation]    "To verify PCRF CCR-I Response contains proper QOS & SDF data, when subscriber usage starts with Standard Tariff after Top-Up Free Data is expired ."
    [Tags]    P1_TOP-UP_FREE_SPECIFIC_CCR-CCA-GX
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_046
    [Documentation]    "To verify PCRF CCR-I Response contains proper QOS & SDF data, when subscriber only top-up free data left is equal to MIN_ACCEPTED_BYTES_LIMIT & Transaction Details is not get updated properly in Transaction Table ."
    [Tags]    P1_TOP-UP_FREE_SPECIFIC_CCR-CCA-GX
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_048
    [Documentation]    "To verify PCRF CCR-I Response contains proper QOS & SDF data, when subscriber done the same normal top-up before expiry of the bundle ."
    [Tags]    P2_TOP-UP_FREE_SPECIFIC_CCR-CCA-GX
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_049
    [Documentation]    "To verify PCRF CCR-I Response contains proper QoS & SDF data, when subscriber has sufficient account balance & No free data ."
    [Tags]    P2_TOP-UP_FREE_SPECIFIC_CCR-CCA-GX
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

*** Keywords ***
