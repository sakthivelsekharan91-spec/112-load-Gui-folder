*** Settings ***
Documentation     PCRF_MULTIPLE_BUNDLE_TEST_SUITE
Suite Setup       SUITE STARTUP
Test teardown     TEST STOP
Force Tags        MULTIPLE_BUNDLE
Default Tags      P2
Test Timeout      5 minutes
Library           Collections
Library           SSHLibrary
Library           OperatingSystem
Library           String
Library           BuiltIn
Library           DateTime
Library           DatabaseLibrary
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_MGTS_CONNECT.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_START_STOP.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_APP_CONNECT.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_SEAGULL_RUN.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_DB_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_LOGGING.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_CDR_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_SUITE_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_PCAP_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_SHELL_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_REMOTE_APP.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_TESTCASE_MODULE.robot
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_MAIN_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_LOGGING_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_CDR_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_DB_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_SEAGULL_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_PCAP_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_SHELL_COMMAND_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_REMOTE_APP_DETAILS.py


*** Variables ***



*** Test Cases ***
PCRF_AUTO_052
    [Documentation]    "To verify PCRF CCR-I Response & RAR contains proper QOS & SDF data, when subscriber has an unlimited bundle & a normal bundle and data session starts with unlimited bundle ."
    [Tags]    CRIT_P1_MULTIPLE_BUNDLE
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_053
    [Documentation]    "To verify PCRF CCR-I Response & RAR contains proper QOS & SDF data, when subscriber has after CAP of unlimited bundle & a normal bundle and data session starts with normal bundle ."
    [Tags]    P1_MULTIPLE_BUNDLE
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_054
    [Documentation]    "To verify PCRF CCR-I Response contains proper QOS & SDF data, when subscriber free data exhausted in both unlimited & normal bundle and data session starts with after CAP of unlimited bundle ."
    [Tags]    P1_MULTIPLE_BUNDLE
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_055
    [Documentation]    "To verify PCRF CCR-I Response contains proper QOS & SDF data, when subscriber free data expired in unlimited bundle & exhausted in normal bundle and data session starts with after CAP of normal bundle ."
    [Tags]    P1_MULTIPLE_BUNDLE
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_056
    [Documentation]    "To verify PCRF CCR-I Response & RAR contains proper QOS & SDF data, when subscriber has an unlimited bundle & a limited bundle and data session starts with unlimited bundle ."
    [Tags]    P1_MULTIPLE_BUNDLE
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_057
    [Documentation]    "To verify PCRF CCR-I Response & RAR contains proper QOS & SDF data, when subscriber has after CAP of unlimited bundle & a limited bundle and data session starts with normal bundle ."
    [Tags]    P1_MULTIPLE_BUNDLE
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_058
    [Documentation]    "To verify PCRF CCR-I Response contains proper QOS & SDF data, when subscriber free data exhausted in both unlimited & limited bundle and data session starts with after CAP of unlimited bundle ."
    [Tags]    P1_MULTIPLE_BUNDLE
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_059
    [Documentation]    "To verify PCRF CCR-I Response contains proper QOS & SDF data, when subscriber free data expired in unlimited & free data exhausted in limited bundle and data session starts with standard tariff ."
    [Tags]    P1_MULTIPLE_BUNDLE
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_061
    [Documentation]    "To verify PCRF CCR-I Response & RAR contains proper QOS & SDF data, when subscriber has after CAP of normal bundle & a limited bundle and data session starts with limited bundle ."
    [Tags]    P1_MULTIPLE_BUNDLE
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_062
    [Documentation]    "To verify PCRF CCR-I Response contains proper QOS & SDF data, when subscriber free data exhausted in both normal & limited bundle and data session starts with after CAP of normal bundle ."
    [Tags]    P2_MULTIPLE_BUNDLE
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

*** Keywords ***
