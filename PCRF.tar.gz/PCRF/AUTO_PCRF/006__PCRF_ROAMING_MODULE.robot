*** Settings ***
Documentation     PCRF_ROAMING_MODULE_TEST_SUITE
Suite Setup       SUITE STARTUP
Test teardown     TEST STOP
Force Tags        ROAMING_MODULE
Default Tags      P2
Test Timeout      5 minutes
Library           Collections
Library           SSHLibrary
Library           OperatingSystem
Library           String
Library           BuiltIn
Library           DateTime
Library           DatabaseLibrary
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_MGTS_CONNECT.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_START_STOP.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_APP_CONNECT.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_SEAGULL_RUN.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_DB_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_LOGGING.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_CDR_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_SUITE_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_PCAP_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_SHELL_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_REMOTE_APP.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_TESTCASE_MODULE.robot
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_MAIN_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_LOGGING_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_CDR_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_DB_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_SEAGULL_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_PCAP_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_SHELL_COMMAND_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_REMOTE_APP_DETAILS.py

*** Variables ***



*** Test Cases ***
PCRF_AUTO_050
    [Documentation]    "To verify PCRF CCR-I Response contains proper QoS & SDF data, when subscriber is in Roaming ."
    [Tags]    CRIT_P1_ROAMING_MODULE
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_051
    [Documentation]    "To verify PCRF CCR-I Response contains proper QoS & SDF data, when subscriber is in Roaming & Account Balance is less than Roam GPRS Minimum Balance ."
    [Tags]    P2_ROAMING_MODULE
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_082
    [Documentation]    "To Verify MO Roaming Bundle Data Call when subscriber has Roaming Bundle"
    [Tags]    CRIT_P1_ROAMING_MODULE
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_083
    [Documentation]    "To Verify MO Roaming Chargeable Data Call when subscriber has Roaming Bundle & SGSN address is not configured under Bundle Plan"
    [Tags]    P2_ROAMING_MODULE
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_084
    [Documentation]    "To verify MO Roaming Data Call when subscriber switches from Bundle to Account Balance"
    [Tags]    P1_ROAMING_MODULE
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_085
    [Documentation]    "To verify MO Roaming Data Call when Roaming Bundle Free Data is exhausted & Subscriber performs MO Roaming Data Call"
    [Tags]    P1_ROAMING_MODULE
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_086
    [Documentation]    "To Verify MO Roaming Bundle Data Call when Used Bytes is sent as Zero in Terminate Request"
    [Tags]    P1_ROAMING_MODULE
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_087
    [Documentation]    "To verify MO Roaming Bundle Data Call when Roam EU CAP Limit is already reached & subscriber has Free Data in Roaming Bundle"
    [Tags]    P1_ROAMING_MODULE
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_088
    [Documentation]    "To verify MO Local Roaming Data Call when Subscriber has Bundle which is applicable for Roaming only."
    [Tags]    P1_ROAMING_MODULE
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_089
    [Documentation]    "To verify MO Roaming Bundle Call when PCRF ID is attached with Roaming Bundle & Subscriber starts data session with Max CAP of Roaming Bundle"
    [Tags]    CRIT_P1_ROAMING_MODULE
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_090
    [Documentation]    "To verify MO Roaming Bundle Call when PCRF ID is attached with Roaming Bundle & Subscriber switches from Max CAP of Roaming Bundle to After CAP of Roaming Bundle"
    [Tags]    P1_ROAMING_MODULE
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_091
    [Documentation]    "To verify MO Roaming Bundle Call when Subscriber starts Data Session with After CAP of Roaming Bundle"
    [Tags]    P2_ROAMING_MODULE
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_092
    [Documentation]    "To verify MO Roaming Limited Bundle Data Call when subscriber switches from Max CAP of Roaming Bundle to Standard Tariff"
    [Tags]    P2_ROAMING_MODULE
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_093
    [Documentation]    "To verify MO Roaming Limited Bundle Data Call when subscriber starts Data Session with Standard Tariff once Free Data is exhausted"
    [Tags]    P1_ROAMING_MODULE
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

*** Keywords ***
