*** Settings ***
Documentation     PCRF_LOCAL_ROAMING_MODULE_TEST_SUITE
Suite Setup       SUITE STARTUP
Test Teardown     TEST STOP
Force Tags        LOCAL_ROAMING_MODULE
Default Tags      P2
Test Timeout      5 minutes
Library           Collections
Library           SSHLibrary
Library           OperatingSystem
Library           String
Library           BuiltIn
Library           DateTime
Library           DatabaseLibrary
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_MGTS_CONNECT.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_START_STOP.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_APP_CONNECT.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_SEAGULL_RUN.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_DB_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_LOGGING.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_CDR_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_SUITE_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_PCAP_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_SHELL_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_REMOTE_APP.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_TESTCASE_MODULE.robot
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_MAIN_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_LOGGING_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_CDR_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_DB_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_SEAGULL_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_PCAP_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_SHELL_COMMAND_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_REMOTE_APP_DETAILS.py

*** Variables ***

*** Test Cases ***

PCRF_AUTO_094
    [Documentation]    "To verify MO Local Roaming Bundle Call when PCRF ID is attached with Roaming Bundle & Local MSISDN Subscriber switches from Max CAP of Roaming Bundle to After CAP of Roaming Bundle""
    [Tags]    P1_LOCAL_ROAMING_MODULE
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_095
    [Documentation]    "To Verify MO Local Roaming Chargeable Data Call when subscriber has Roaming Bundle & SGSN address is not configured under Bundle Plan"
    [Tags]    P1_LOCAL_ROAMING_MODULE
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_096
    [Documentation]    "To verify MO Local Roaming Data Call when subscriber switches from Bundle to Account Balance"
    [Tags]    P1_LOCAL_ROAMING_MODULE
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_097
    [Documentation]    "To verify MO Local Roaming Data Call when Roaming Bundle Free Data is exhausted & Subscriber performs MO Roaming Data Call"
    [Tags]    P2_LOCAL_ROAMING_MODULE
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_098
    [Documentation]    "To Verify MO Local Roaming Bundle Data Call when Used Bytes is sent as Zero in Terminate Request"
    [Tags]    P1_LOCAL_ROAMING_MODULE
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_099
    [Documentation]    "To verify MO Roaming Data Call when Subscriber has Bundle which is applicable for Local Roaming only"
    [Tags]    P2_LOCAL_ROAMING_MODULE
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_100
    [Documentation]    "To verify MO Local Roaming Bundle Call when PCRF ID is attached with Roaming Bundle & Subscriber starts data session with Max CAP of Local Roaming Bundle"
    [Tags]    P1_LOCAL_ROAMING_MODULE
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_101
    [Documentation]    "To verify MO Local Roaming Bundle Call when PCRF ID is attached with Roaming Bundle & Subscriber switches from Max CAP of Roaming Bundle to After CAP of Roaming Bundle"
    [Tags]    P1_LOCAL_ROAMING_MODULE
    Set Test Variable    ${MSISDN}    7438691063
    Set Test Variable    ${BUNDLE_CODE}    9885
    Set Test Variable    ${TARIFF_CODE}    0
    ${TC_RESULT} =    START AUTO MSISDN
    log    ${TC_RESULT}

PCRF_AUTO_102
    [Documentation]    "To verify MO Local Roaming Bundle Call when Subscriber starts Data Session with After CAP of Roaming Bundle"
    [Tags]    P1_LOCAL_ROAMING_MODULE_FAIL
    Set Test Variable    ${MSISDN}    7438691063
    Set Test Variable    ${BUNDLE_CODE}    9885
    Set Test Variable    ${TARIFF_CODE}    0
    ${TC_RESULT} =    START AUTO MSISDN
    log    ${TC_RESULT}

PCRF_AUTO_103
    [Documentation]    "To verify MO Local Roaming Limited Bundle Data Call when subscriber switches from Max CAP of Roaming Bundle to Standard Tariff"
    [Tags]    P2_LOCAL_ROAMING_MODULE_FAIL
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_104
    [Documentation]    "To verify MO Local Roaming Limited Bundle Data Call when subscriber starts Data Session with Standard Tariff once Free Data is exhausted"
    [Tags]    P1_LOCAL_ROAMING_MODULE
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_105
    [Documentation]    "To Verify MO Local Roaming Bundle Data Call when Local MSISDN subscriber has Local Roaming Bundle"
    [Tags]    CRIT_P1_LOCAL_ROAMING_MODULE
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_106
    [Documentation]    "To Verify MO Local Roaming Chargeable Data Call when Local MSISDN subscriber has Roaming Bundle & SGSN address is not configured under Bundle Plan"
    [Tags]    P2_LOCAL_ROAMING_MODULE
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_107
    [Documentation]    "To verify MO Local Roaming Data Call when Local MSISDN subscriber switches from Bundle to Account Balance"
    [Tags]    P1_LOCAL_ROAMING_MODULE
    Set Test Variable    ${MSISDN}    7438691065
    Set Test Variable    ${BUNDLE_CODE}    9884
    Set Test Variable    ${TARIFF_CODE}    0
    ${TC_RESULT} =    START AUTO MSISDN
    log    ${TC_RESULT}

PCRF_AUTO_108
    [Documentation]    "To verify MO Local Roaming Data Call when Roaming Bundle Free Data is exhausted & Local MSISDN Subscriber performs MO Roaming Data Call"
    [Tags]    P1_LOCAL_ROAMING_MODULE
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_109
    [Documentation]    "To Verify MO Local Roaming Bundle Data Call when Used Bytes is sent as Zero in Terminate Request for Local MSISDN subscriber"
    [Tags]    P2_LOCAL_ROAMING_MODULE
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_110
    [Documentation]    "To verify MO Roaming Data Call when Local MSISDN Subscriber has Bundle which is applicable for Local Roaming only"
    [Tags]    P2_LOCAL_ROAMING_MODULE
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_111
    [Documentation]    "To verify MO Local Roaming Bundle Call when PCRF ID is attached with Roaming Bundle & Local MSISDN Subscriber starts data session with Max CAP of Roaming Bundle"
    [Tags]    P1_LOCAL_ROAMING_MODULE
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_112
    [Documentation]    "To verify MO Local Roaming Bundle Call when PCRF ID is attached with Roaming Bundle & Local MSISDN Subscriber switches from Max CAP of Roaming Bundle to After CAP of Roaming Bundle"
    [Tags]    P1_LOCAL_ROAMING_MODULE_FAIL
    Set Test Variable    ${MSISDN}    7438691066
    Set Test Variable    ${BUNDLE_CODE}    9885
    Set Test Variable    ${TARIFF_CODE}    0
    ${TC_RESULT} =    START AUTO MSISDN
    log    ${TC_RESULT}

PCRF_AUTO_113
    [Documentation]    "To verify MO Local Roaming Bundle Call when Local MSISDN Subscriber starts Data Session with After CAP of Roaming Bundle"
    [Tags]    P1_LOCAL_ROAMING_MODULE_FAIL
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_114
    [Documentation]    "To verify MO Local Roaming Limited Bundle Data Call when Local MSISDN subscriber switches from Max CAP of Roaming Bundle to Standard Tariff"
    [Tags]    P2_LOCAL_ROAMING_MODULE
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_115
    [Documentation]    "To verify MO Local Roaming Limited Bundle Data Call when Local MSISDN subscriber starts Data Session with Standard Tariff once Free Data is exhausted"
    [Tags]    P1_LOCAL_ROAMING_MODULE
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

*** KeyWords ***
