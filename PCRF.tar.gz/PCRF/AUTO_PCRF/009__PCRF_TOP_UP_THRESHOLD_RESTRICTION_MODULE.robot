*** Settings ***
Documentation     PCRF_TOP_UP_THESHOLD_RESTRICTION_MODULE_TEST_SUITE
Suite Setup       SUITE STARTUP
Test teardown     TEST STOP
Force Tags        TOP_UP_THESHOLD_RESTRICTION_MODULE
Default Tags      P2
Test Timeout      5 minutes
Library           Collections
Library           SSHLibrary
Library           OperatingSystem
Library           String
Library           BuiltIn
Library           DateTime
Library           DatabaseLibrary
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_MGTS_CONNECT.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_START_STOP.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_APP_CONNECT.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_SEAGULL_RUN.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_DB_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_LOGGING.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_CDR_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_SUITE_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_PCAP_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_SHELL_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_REMOTE_APP.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_TESTCASE_MODULE.robot
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_MAIN_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_LOGGING_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_CDR_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_DB_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_SEAGULL_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_PCAP_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_SHELL_COMMAND_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_REMOTE_APP_DETAILS.py

*** Variables ***


*** Test Cases ***
PCRF_AUTO_122
    [Documentation]    "To verify whether Subscriber is not able to use free Data when Subscriber account balance is less than Free Top-Up Threshold Balance configured with Expire Free Action Flag"
    [Tags]    CRIT_P1_TOP_UP_THESHOLD_RESTRICTION_MODULE
    Set Test Variable    ${SHELL_PRE_CMD}    1
    Set Test Variable    ${MSISDN}    7438691068
    ${TC_RESULT} =    START AUTO MSISDN
    log    ${TC_RESULT}

PCRF_AUTO_123
    [Documentation]    "To verify whether Subscriber is able to use free Data when Subscriber account balance is equal to Free Top-Up Threshold Balance configured with Expire Free Action Flag"
    [Tags]    P1_TOP_UP_THESHOLD_RESTRICTION_MODULE
    Set Test Variable    ${MSISDN}    7438691068
    ${TC_RESULT} =    START AUTO MSISDN
    log    ${TC_RESULT}

PCRF_AUTO_124
    [Documentation]    "To verify whether Subscriber is able to use free Data when Subscriber account balance is greater than Free Top-Up Threshold Balance configured with Expire Free Action Flag"
    [Tags]    P1_TOP_UP_THESHOLD_RESTRICTION_MODULE
    Set Test Variable    ${MSISDN}    7438691068
    ${TC_RESULT} =    START AUTO MSISDN
    log    ${TC_RESULT}

PCRF_AUTO_125
    [Documentation]    "To verify whether Subscriber is able to use free Data when Subscriber account balance is greater than Free Top-Up Threshold Balance accounting Reserve Amount but less than free top-up threshold without accounting Reserve Amount configured with Expire Free Action Flag"
    [Tags]    P1_TOP_UP_THESHOLD_RESTRICTION_MODULE
    Set Test Variable    ${MSISDN}    7438691068
    ${TC_RESULT} =    START AUTO MSISDN
    log    ${TC_RESULT}

PCRF_AUTO_126
    [Documentation]    "To verify whether Subscriber is not able to use free Data from bundle when Subscriber account balance is less than both GPRS Minimum Balance & Free Top-Up Threshold Balance Balance configured"
    [Tags]    P1_TOP_UP_THESHOLD_RESTRICTION_MODULE
    Set Test Variable    ${MSISDN}    7438691068
    ${TC_RESULT} =    START AUTO MSISDN
    log    ${TC_RESULT}

PCRF_AUTO_127
    [Documentation]    "To verify whether subscriber is able to use Bundle free data when subscriber account balance is less than Free Top-Up Threshold Balance"
    [Tags]    P1_TOP_UP_THESHOLD_RESTRICTION_MODULE
    Set Test Variable    ${MSISDN}    7438691070
    ${TC_RESULT} =    START AUTO MSISDN
    log    ${TC_RESULT}

PCRF_AUTO_128
    [Documentation]    "To verify whether PCRF entries get resetted upon expiring free units when Top-Up Free Data is attached to PCRF"
    [Tags]    P2_TOP_UP_THESHOLD_RESTRICTION_MODULE
    Set Test Variable    ${MSISDN}    7438691071
    ${TC_RESULT} =    START AUTO MSISDN
    log    ${TC_RESULT}

PCRF_AUTO_129
    [Documentation]    "To verify whether Subscriber is not able to use free Data when Subscriber account balance is less than Free Top-Up Threshold Balance configured with RAT Free Action Flag"
    [Tags]    CRIT_P1_TOP_UP_THESHOLD_RESTRICTION_MODULE
    Set Test Variable    ${SHELL_PRE_CMD}    ${1}
    Set Test Variable    ${MSISDN}    7438691072
    ${TC_RESULT} =    START AUTO MSISDN
    log    ${TC_RESULT}

PCRF_AUTO_130
    [Documentation]    "To verify whether Subscriber is able to use free Data when Subscriber account balance is equal to Free Top-Up Threshold Balance configured with RAT Free Action Flag"
    [Tags]    P1_TOP_UP_THESHOLD_RESTRICTION_MODULE
    Set Test Variable    ${MSISDN}    7438691072
    ${TC_RESULT} =    START AUTO MSISDN
    log    ${TC_RESULT}

PCRF_AUTO_131
    [Documentation]    "To verify whether Subscriber is able to use free Data when Subscriber account balance is greater than Free Top-Up Threshold Balance configured with RAT Free Action Flag"
    [Tags]    P1_TOP_UP_THESHOLD_RESTRICTION_MODULE
    Set Test Variable    ${MSISDN}    7438691072
    ${TC_RESULT} =    START AUTO MSISDN
    log    ${TC_RESULT}

PCRF_AUTO_132
    [Documentation]    "To To verify whether Subscriber is able to use free Data when Subscriber account balance is greater than Free Top-Up Threshold Balance accounting Reserve Amount but less than free top-up threshold without accounting Reserve Amount configured with RAT Free Action Flag"
    [Tags]    P1_TOP_UP_THESHOLD_RESTRICTION_MODULE
    Set Test Variable    ${MSISDN}    7438691072
    ${TC_RESULT} =    START AUTO MSISDN
    log    ${TC_RESULT}

PCRF_AUTO_134
    [Documentation]    "To verify whether subscriber is able to use Bundle free data when subscriber account balance is less than Free Top-Up Threshold Balance"
    [Tags]    P2_TOP_UP_THESHOLD_RESTRICTION_MODULE
    Set Test Variable    ${MSISDN}    7438691073
    ${TC_RESULT} =    START AUTO MSISDN
    log    ${TC_RESULT}

PCRF_AUTO_135
    [Documentation]    "To verify whether PCRF entries is not get resetted upon expiring free units when Top-Up Free Data is attached to PCRF"
    [Tags]    P2_TOP_UP_THESHOLD_RESTRICTION_MODULE
    Set Test Variable    ${MSISDN}    7438691074
    ${TC_RESULT} =    START AUTO MSISDN
    log    ${TC_RESULT}

*** KeyWords ***
