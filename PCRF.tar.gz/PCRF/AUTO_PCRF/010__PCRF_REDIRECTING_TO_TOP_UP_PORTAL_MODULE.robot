*** Settings ***
Documentation     PCRF_REDIRECTING_TO_TOP_UP_PORTAL_MODULE_TEST_SUITE
Suite Setup       SUITE STARTUP
Test teardown     TEST STOP
Force Tags        REDIRECTING_TO_TOP_UP_PORTAL_MODULE
Default Tags      P2
Test Timeout      5 minutes
Library           Collections
Library           SSHLibrary
Library           OperatingSystem
Library           String
Library           BuiltIn
Library           DateTime
Library           DatabaseLibrary
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_MGTS_CONNECT.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_START_STOP.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_APP_CONNECT.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_SEAGULL_RUN.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_DB_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_LOGGING.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_CDR_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_SUITE_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_PCAP_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_SHELL_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_REMOTE_APP.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_TESTCASE_MODULE.robot
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_MAIN_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_LOGGING_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_CDR_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_DB_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_SEAGULL_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_PCAP_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_SHELL_COMMAND_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_REMOTE_APP_DETAILS.py

*** Variables ***


*** Test Cases ***
PCRF_AUTO_140
    [Documentation]    "To verify whether subscriber is re-directed to Top-Up portal when Subscriber account is out of credit during Initial Interrogation"
    [Tags]    CRIT_P1_REDIRECTING_TO_TOP_UP_PORTAL_MODULE
    Set Test Variable    ${SHELL_PRE_CMD}    1
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_141
    [Documentation]    "To verify whether subscriber is re-directed to Top-Up portal when Subscriber account is out of credit during Initial Interrogation"
    [Tags]    P1_REDIRECTING_TO_TOP_UP_PORTAL_MODULE
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_142
    [Documentation]    "To verify whether subscriber is re-directed to Top-Up portal when Subscriber bundle is out of credit during Subsequent Interrogation"
    [Tags]    P1_REDIRECTING_TO_TOP_UP_PORTAL_MODULE
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_143
    [Documentation]    "To verify whether subscriber is re-directed to Top-Up portal when Subscriber bundle and account balance is out of credit during Subsequent Interrogation"
    [Tags]    P2_REDIRECTING_TO_TOP_UP_PORTAL_MODULE
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_144
    [Documentation]    "To verify whether subscriber is re-directed to Top-Up portal when Subscriber account is out of credit during Initial Interrogation when RG is enabled"
    [Tags]    P2_REDIRECTING_TO_TOP_UP_PORTAL_MODULE
    Set Test Variable    ${SHELL_PRE_CMD}    1
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

*** KeyWords ***
