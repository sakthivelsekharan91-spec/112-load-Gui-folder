*** Settings ***
Documentation     PCRF_DIFFERENTIAL_DATA_CHARGING_MODULE_TEST_SUITE
Suite Setup       SUITE STARTUP
Test teardown     TEST STOP
Force Tags        DIFFERENTIAL_DATA_CHARGING_MODULE
Default Tags      P2
Test Timeout      5 minutes
Library           Collections
Library           SSHLibrary
Library           OperatingSystem
Library           String
Library           BuiltIn
Library           DateTime
Library           DatabaseLibrary
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_MGTS_CONNECT.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_START_STOP.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_APP_CONNECT.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_SEAGULL_RUN.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_DB_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_LOGGING.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_CDR_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_SUITE_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_PCAP_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_SHELL_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_REMOTE_APP.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_TESTCASE_MODULE.robot
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_MAIN_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_LOGGING_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_CDR_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_DB_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_SEAGULL_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_PCAP_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_SHELL_COMMAND_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_REMOTE_APP_DETAILS.py

*** Variables ***

*** Test Cases ***
PCRF_AUTO_145
    [Documentation]    "To verify whether 4G based Data Charging is taking place when 4G service is activated for the Subscriber and Subscriber initiates Data Session from E-UTRAN RAT Area"
    [Tags]    CRIT_P1_DIFFERENTIAL_DATA_CHARGING_MODULE
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_146
    [Documentation]    "To verify the differential Data Charging behaviour when Subscriber starts Data Session in 4G Coverage Area and switches to 3G Coverage Area once consumed all the units granted for 4G RAT"
    [Tags]    P1_DIFFERENTIAL_DATA_CHARGING_MODULE
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_147
    [Documentation]    "To verify the differential Data Charging behaviour when Subscriber starts Data Session in 2G Coverage Area and switches to 4G Coverage Area while Partial Units of granted for 2G Coverage is used"
    [Tags]    P1_DIFFERENTIAL_DATA_CHARGING_MODULE
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_148
    [Documentation]    "To verify the differential Data Charging behaviour when Subscriber starts Data Session in 3G Coverage Area and switches to 2G Coverage Area once consumed all the units granted for 3G RAT when CCR-Initial Request is received without MSCC AVP"
    [Tags]    P1_DIFFERENTIAL_DATA_CHARGING_MODULE
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_150
    [Documentation]    "To verify whether Core has not been generated when subscriber has Top-Up free Data,Roam Bundle and Normal Bundle & PCRF Initial Request has sent"
    [Tags]    P1_DIFFERENTIAL_DATA_CHARGING_MODULE
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_151
    [Documentation]    "To verify the behaviour of data charging when Subscriber has an unlimited bundle and a normal bundle where unlimited bundle has higher priority & Subscriber switches from unlimited bundle to normal bundle"
    [Tags]    P1_DIFFERENTIAL_DATA_CHARGING_MODULE
    Set Test Variable    ${SHELL_PRE_CMD}    1
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_152
    [Documentation]    "To verify the behaviour of data charging when Subscriber has an unlimited bundle and a normal bundle where unlimited bundle has higher priority and subscriber switches from normal bundle to after cap of unlimited bundle"
    [Tags]    P1_DIFFERENTIAL_DATA_CHARGING_MODULE
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_153
    [Documentation]    "To verify the behaviour of data charging when subscriber free data exhausted in both unlimited bundle & normal bundle where unlimited bundle has higher priority and data session starts with after CAP of unlimited bundle
    [Tags]    P1_DIFFERENTIAL_DATA_CHARGING_MODULE
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_154
    [Documentation]    "To verify the behaviour of data charging when subscriber free data expired in unlimited bundle & exhausted in normal bundle where unlimited bundle has higher priority and data session starts with after CAP of normal bundle"
    [Tags]    P1_DIFFERENTIAL_DATA_CHARGING_MODULE
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_155
    [Documentation]    "To verify whether subscriber is able to use from account balance when Delcom based data charging is enabled and subscriber has used partial granted units at 4G Speed"
    [Tags]    P1_DIFFERENTIAL_DATA_CHARGING_MODULE
    Set Test Variable    ${SHELL_PRE_CMD}    1
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_156
    [Documentation]    "To verify whether subscriber is able to use from account balance when Delcom based data charging is enabled and subscriber has used complete granted units at 4G Speed"
    [Tags]    P1_DIFFERENTIAL_DATA_CHARGING_MODULE
    Set Test Variable    ${TC_NAME}    PCRF_AUTO_156
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_157
    [Documentation]    "To verify whether subscriber is able to use from account balance when Delcom based data charging is enabled and subscriber has used complete granted units at 2G Speed"
    [Tags]    P2_DIFFERENTIAL_DATA_CHARGING_MODULE
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

*** KeyWords ***
