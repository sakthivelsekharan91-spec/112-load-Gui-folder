*** Settings ***
Documentation     PCRF_BUNDLE_EXPIRY_BASED_CHARGING_RULE_INSTALLATION_MODULE_MODULE_TEST_SUITE
Suite Setup       SUITE STARTUP
Test teardown     TEST STOP
Force Tags        BUNDLE_EXPIRY_BASED_CHARGING_RULE_INSTALLATION_MODULE
Default Tags      P2
Test Timeout      5 minutes
Library           Collections
Library           SSHLibrary
Library           OperatingSystem
Library           String
Library           BuiltIn
Library           DateTime
Library           DatabaseLibrary
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_MGTS_CONNECT.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_START_STOP.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_APP_CONNECT.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_SEAGULL_RUN.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_DB_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_LOGGING.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_CDR_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_SUITE_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_PCAP_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_SHELL_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_REMOTE_APP.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_TESTCASE_MODULE.robot
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_MAIN_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_LOGGING_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_CDR_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_DB_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_SEAGULL_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_PCAP_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_SHELL_COMMAND_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_REMOTE_APP_DETAILS.py


*** Variables ***
${LOGGER_Validation}               1
${CDR_Validation}                  0
${PRE_DB_Validation}               1
${POST_DB_QUERY_Validation}        0

*** Test Cases ***
PCRF_AUTO_161
    [Documentation]    "To verify whether PCRF is installing Chargng Rule of Bundle with Rule Deactivation Time when Bundle is expiring by today ."
    [Tags]    CRIT_P1_BUNDLE_EXPIRY_BASED_CHARGING_RULE_INSTALLATION_MODULE
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_162
    [Documentation]    "To verify whether PCRF is installing Chargng Rule of Bundle with Rule Deactivation Time when Bundle is expiring by tomorrow ."
    [Tags]    P1_BUNDLE_EXPIRY_BASED_CHARGING_RULE_INSTALLATION_MODULE
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_163
    [Documentation]    "To verify whether PCRF is installing Chargng Rule of Bundle with Rule Deactivation Time when Bundle is expiring by day after ."
    [Tags]    P1_BUNDLE_EXPIRY_BASED_CHARGING_RULE_INSTALLATION_MODULE
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_164
    [Documentation]    "To verify whether PCRF is installing Chargng Rule of Bundle with Rule Deactivation Time with tariff ."
    [Tags]    P1_BUNDLE_EXPIRY_BASED_CHARGING_RULE_INSTALLATION_MODULE
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_165
    [Documentation]    "To verify whether PCRF is installing same Chargng Rule for both bundle & tariff when bundle expiring today ."
    [Tags]    P1_BUNDLE_EXPIRY_BASED_CHARGING_RULE_INSTALLATION_MODULE
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_166
    [Documentation]    "To verify whether PCRF is installing Chargng Rule of Bundle with Rule Deactivation Time when 2 bundle expiring today ."
    [Tags]    P1_BUNDLE_EXPIRY_BASED_CHARGING_RULE_INSTALLATION_MODULE
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_167
    [Documentation]    "To verify whether PCRF is installing Chargng Rule of Bundle with Rule Deactivation Time when 1 bundle expiring today & other tomorrow ."
    [Tags]    P1_BUNDLE_EXPIRY_BASED_CHARGING_RULE_INSTALLATION_MODULE
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_168
    [Documentation]    "To verify whether PCRF is installing Chargng Rule of Bundle with Rule Deactivation Time when 1 bundle expiring today & other a day after ."
    [Tags]    P1_BUNDLE_EXPIRY_BASED_CHARGING_RULE_INSTALLATION_MODULE
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_169
    [Documentation]    "To verify whether PCRF is installing Chargng Rule of Bundle with Rule Deactivation Time when 1 bundle expiring today & other tomorrow different charging rule ."
    [Tags]    P1_BUNDLE_EXPIRY_BASED_CHARGING_RULE_INSTALLATION_MODULE
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_170
    [Documentation]    "To verify whether PCRF is installing Chargng Rule of Bundle with Rule Deactivation Time when 1 bundle expiring today & other a day after with same chaging rule ."
    [Tags]    P1_BUNDLE_EXPIRY_BASED_CHARGING_RULE_INSTALLATION_MODULE
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_171
    [Documentation]    "To verify whether PCRF is installing different Chargng Rule of two Bundles with Rule Deactivation Time when 1 bundle expiring today & other after 30 days with different chaging rule in initiate(4G) & update(2G) ."
    [Tags]    P2_BUNDLE_EXPIRY_BASED_CHARGING_RULE_INSTALLATION_MODULE
    Set Test Variable    ${SHELL_PRE_CMD}    1
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_172
    [Documentation]    "To verify whether PCRF is installing different Chargng Rule of two Bundles with Rule Deactivation Time when 1 bundle expiring today & other after 30 days with different chaging rule in initiate(2G) & update(4G) ."
    [Tags]    P2_BUNDLE_EXPIRY_BASED_CHARGING_RULE_INSTALLATION_MODULE
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

*** KeyWords ***
