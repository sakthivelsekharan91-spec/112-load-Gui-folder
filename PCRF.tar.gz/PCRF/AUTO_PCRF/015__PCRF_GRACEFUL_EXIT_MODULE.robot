*** Settings ***
Documentation     PCRF_GRACEFUL_EXIT_MODULE_TEST_SUITE
Suite Setup       SUITE STARTUP
Test teardown     TEST STOP
Force Tags        PCRF_GRACEFUL_EXIT_MODULE
Default Tags      P2
Test Timeout      5 minutes
Library           Collections
Library           SSHLibrary
Library           OperatingSystem
Library           String
Library           BuiltIn
Library           DateTime
Library           DatabaseLibrary
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_MGTS_CONNECT.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_START_STOP.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_APP_CONNECT.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_SEAGULL_RUN.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_DB_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_LOGGING.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_CDR_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_SUITE_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_PCAP_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_SHELL_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_REMOTE_APP.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_TESTCASE_MODULE.robot
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_MAIN_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_LOGGING_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_CDR_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_DB_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_SEAGULL_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_PCAP_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_SHELL_COMMAND_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_REMOTE_APP_DETAILS.py

*** Variables ***
${SHELL_ON_CALL_CMD}    1


*** Test Cases ***
PCRF_AUTO_183
    [Documentation]    "To verify the behaviour of PCRF during graceful shutdown ."
    [Tags]    CRIT_P1_PCRF_GRACEFUL_EXIT_MODULE
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_184
    [Documentation]    "To verify the behaviour of PCRF when CCR-Terminate Request is not received after receiving ASA ."
    [Tags]    P1_PCRF_GRACEFUL_EXIT_MODULE
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_185
    [Documentation]    "To verify the behaviour of PCRF during ASR Timeout ."
    [Tags]    P1_PCRF_GRACEFUL_EXIT_MODULE
    Set Test Variable    ${POST_SLEEP_EXECUTION}    ${60}
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_186
    [Documentation]    "To verify the behaviour of PCRF when CCR-Terminate Request is received by PCRF before ASA during greceful shutdown ."
    [Tags]    P1_PCRF_GRACEFUL_EXIT_MODULE
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_187
    [Documentation]    "To verify the behaviour of PCRF when PCRF goes down grecefully after sending CCA-Update Request ."
    [Tags]    P1_PCRF_GRACEFUL_EXIT_MODULE
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_188
    [Documentation]    "To verify the behaviour of PCRF when negative ASA is received from GGSN during graceful exit ."
    [Tags]    P2_PCRF_GRACEFUL_EXIT_MODULE
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_189
    [Documentation]    "To verify the behaviour of PCRF when negative response is sent to a data session and PCRF goes down gracefully ."
    [Tags]    P2_PCRF_GRACEFUL_EXIT_MODULE
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

*** KeyWords ***
