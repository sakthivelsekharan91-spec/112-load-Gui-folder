*** Settings ***
Documentation     PCRF_AN_GW_ADDRESS_MCC_MNC_MODULE_TEST_SUITE
Suite Setup       SUITE STARTUP
Test teardown     TEST STOP
Force Tags        PCRF_AN_GW_ADDRESS_MCC_MNC_MODULE
Default Tags      P2
Test Timeout      5 minutes
Library           Collections
Library           SSHLibrary
Library           OperatingSystem
Library           String
Library           BuiltIn
Library           DateTime
Library           DatabaseLibrary
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_MGTS_CONNECT.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_START_STOP.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_APP_CONNECT.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_SEAGULL_RUN.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_DB_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_LOGGING.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_CDR_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_SUITE_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_PCAP_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_SHELL_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_REMOTE_APP.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_TESTCASE_MODULE.robot
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_MAIN_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_LOGGING_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_CDR_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_DB_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_SEAGULL_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_PCAP_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_SHELL_COMMAND_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_REMOTE_APP_DETAILS.py

*** Variables ***

*** Test Cases ***

PCRF_AUTO_193
    [Documentation]    "To verify whether PCRF is properly decoding AN-GW-ADDRESS AVP properly received in CCR-I."
    [Tags]    CRIT_P1_PCRF_AN_GW_ADDRESS_MCC_MNC_MODULE
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_194
    [Documentation]    "To verify whether PCRF is decoding AN-GW Address AVP properly when both SGSN Address and AN-GW-Address received in CCR-I."
    [Tags]    P1_PCRF_AN_GW_ADDRESS_MCC_MNC_MODULE
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_195
    [Documentation]    "To verify whether PCRF is decoding MCC-MNC properly upon receiving CCR-I with Geographic Location Type as 00."
    [Tags]    P1_PCRF_AN_GW_ADDRESS_MCC_MNC_MODULE
    Set Test Variable    ${SHELL_PRE_CMD}    1
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_196
    [Documentation]    "To verify whether PCRF is decoding MCC-MNC properly upon receiving CCR-I with Geographic Location Type as CGI."
    [Tags]    P1_PCRF_AN_GW_ADDRESS_MCC_MNC_MODULE
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_197
    [Documentation]    "To verify whether PCRF is decoding MCC-MNC properly upon receiving CCR-I with Geographic Location Type as SAI."
    [Tags]    P1_PCRF_AN_GW_ADDRESS_MCC_MNC_MODULE
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_198
    [Documentation]    "To verify whether PCRF is decoding MCC-MNC properly upon receiving CCR-I with Geographic Location Type as RAI."
    [Tags]    P1_PCRF_AN_GW_ADDRESS_MCC_MNC_MODULE
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_199
    [Documentation]    "To verify whether PCRF is decoding MCC-MNC properly upon receiving CCR-I with Geographic Location Type as TAI."
    [Tags]    P1_PCRF_AN_GW_ADDRESS_MCC_MNC_MODULE
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_200
    [Documentation]    "To verify whether PCRF is decoding MCC-MNC properly upon receiving CCR-I with Geographic Location Type as ECGI."
    [Tags]    P1_PCRF_AN_GW_ADDRESS_MCC_MNC_MODULE
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_201
    [Documentation]    "To verify whether PCRF is decoding MCC-MNC properly upon receiving CCR-I with Geographic Location Type as LAI."
    [Tags]    P1_PCRF_AN_GW_ADDRESS_MCC_MNC_MODULE
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_249
    [Documentation]    "To verify whether PCRF is decoding Zero Values of MCC-MNC properly upon receiving CCR-I with Geographic Location Type as LAI."
    [Tags]    P1_PCRF_AN_GW_ADDRESS_MCC_MNC_MODULE
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_238
    [Documentation]    "To verify whether PCRF is decoding MCC-MNC properly from RAI AVP upon receiving CCR-I."
    [Tags]    P1_PCRF_AN_GW_ADDRESS_MCC_MNC_MODULE
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_239
    [Documentation]    "To verify whether PCRF is decoding MCC-MNC properly from 3GPP-SGSN-MCC-MNC AVP upon receiving CCR-I."
    [Tags]    P1_PCRF_AN_GW_ADDRESS_MCC_MNC_MODULE
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_240
    [Documentation]    "To verify whether PCRF is decoding MCC-MNC properly from RAI AVP upon receiving CCR-I when MNC is 1 Digit"
    [Tags]    P1_PCRF_AN_GW_ADDRESS_MCC_MNC_MODULE
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_241
    [Documentation]    "To verify whether PCRF is decoding MCC-MNC properly from RAI AVP upon receiving CCR-I when MNC is 3 Digit."
    [Tags]    P1_PCRF_AN_GW_ADDRESS_MCC_MNC_MODULE
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_265
    [Documentation]    "To verify whether PCRF is decoding MCC-MNC properly from 3GPP-SGSN-MCC-MNC AVP upon receiving CCR-I when MNC is 3 Digit."
    [Tags]    P1_PCRF_AN_GW_ADDRESS_MCC_MNC_MODULE
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_266
    [Documentation]    "To verify whether PCRF is decoding MCC-MNC properly from 3GPP-SGSN-MCC-MNC AVP upon receiving CCR-I when MNC is 1 Digit."
    [Tags]    P1_PCRF_AN_GW_ADDRESS_MCC_MNC_MODULE
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_267
    [Documentation]    "To verify behaviour of PCRF when User Location Info and 3GPP-SGSN-MCC-MNC AVP is not received in CCR-I."
    [Tags]    P1_PCRF_AN_GW_ADDRESS_MCC_MNC_MODULE
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

*** KeyWords ***
