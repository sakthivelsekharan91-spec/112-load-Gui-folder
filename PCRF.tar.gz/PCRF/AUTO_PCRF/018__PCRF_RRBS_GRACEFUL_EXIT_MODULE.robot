*** Settings ***
Documentation     PCRF_RRBS_GRACEFUL_EXIT_MODULE
Suite Setup       SUITE STARTUP
Test teardown     TEST STOP
Force Tags        PCRF_RRBS_GRACEFUL_EXIT_MODULE
Default Tags      P2
Test Timeout      5 minutes
Library           Collections
Library           SSHLibrary
Library           OperatingSystem
Library           String
Library           BuiltIn
Library           DateTime
Library           DatabaseLibrary
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_MGTS_CONNECT.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_START_STOP.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_APP_CONNECT.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_SEAGULL_RUN.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_DB_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_LOGGING.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_CDR_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_SUITE_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_PCAP_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_SHELL_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_REMOTE_APP.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_TESTCASE_MODULE.robot
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_MAIN_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_LOGGING_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_CDR_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_DB_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_SEAGULL_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_PCAP_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_SHELL_COMMAND_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_REMOTE_APP_DETAILS.py

*** Variables ***
${SHELL_ON_CALL_CMD}    1


*** Test Cases ***

PCRF_AUTO_208
    [Documentation]    "To verify PCRF sends ASR to GGSN for sessions handled by primary RRBS when RRBS goes down gracefully ."
    [Tags]    CRIT_P1_PCRF_RRBS_GRACEFUL_EXIT_MODULE
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_209
    [Documentation]    "To verify whether PCRF sends Initial Request to Secondary RRBS when Primary RRBS goes down gracefully and Grace Period is not expired."
    [Tags]    P1_PCRF_RRBS_GRACEFUL_EXIT_MODULE
    Set Test Variable    ${SHELL_PRE_CMD}       1
    Set Test Variable    ${${POST_SLEEP_EXECUTION}}       11
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_210
    [Documentation]    "To verify PCRF sends  ASR to GGSN for sessions handled by secondary RRBS when Grace Period Expired."
    [Tags]    P1_PCRF_RRBS_GRACEFUL_EXIT_MODULE
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_242
    [Documentation]    "To verify whether PCRF sends Initial Request to Primary RRBS when Grace Period of Secondary RRBS expired and Primary RRBS comes up successfully."
    [Tags]    P2_PCRF_RRBS_GRACEFUL_EXIT_MODULE
    Set Test Variable    ${SHELL_PRE_CMD}       1
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_243
    [Documentation]    "To verify whether PCRF sends Initial Request to Secondary RRBS when Grace Period of Secondary RRBS expired and Primary RRBS not comes up successfully."
    [Tags]    P2_PCRF_RRBS_GRACEFUL_EXIT_MODULE
    Set Test Variable    ${SHELL_PRE_CMD}       1
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_244
    [Documentation]    "To verify behaviour of ASR Time-out during RRBS Graceful shutdown case."
    [Tags]    P2_PCRF_RRBS_GRACEFUL_EXIT_MODULE
    Set Test Variable    ${SHELL_PRE_CMD}       1
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}



*** keywords **