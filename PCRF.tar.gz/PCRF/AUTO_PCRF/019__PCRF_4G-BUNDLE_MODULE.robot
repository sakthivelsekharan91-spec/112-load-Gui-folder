*** Settings ***
Documentation     PCRF_4G_BUNDLE_MODULE
Suite Setup       SUITE STARTUP
Test teardown     TEST STOP
Force Tags        PCRF_4G_BUNDLE_MODULE
Default Tags      P2
Test Timeout      5 minutes
Library           Collections
Library           SSHLibrary
Library           OperatingSystem
Library           String
Library           BuiltIn
Library           DateTime
Library           DatabaseLibrary
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_MGTS_CONNECT.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_START_STOP.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_APP_CONNECT.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_SEAGULL_RUN.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_DB_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_LOGGING.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_CDR_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_SUITE_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_PCAP_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_SHELL_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_REMOTE_APP.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_TESTCASE_MODULE.robot
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_MAIN_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_LOGGING_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_CDR_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_DB_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_SEAGULL_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_PCAP_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_SHELL_COMMAND_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_REMOTE_APP_DETAILS.py

*** Variables ***


*** Test Cases ***

PCRF_AUTO_250
    [Documentation]    "To verify whether PCRF is installing 4G-Charging-Rule of the Bundle  when subsriber is having 4G Only Bundle and latched in 4G RAT."
    [Tags]    CRIT_P1_PCRF_4G_BUNDLE_MODULE
    Set Test Variable    ${SHELL_PRE_CMD}       1
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_251
    [Documentation]    "To verify whether PCRF is not installing Charging-Rule of the Bundle  when subsriber is having 4G Only Bundle and latched in 3G/2G RAT and thus restricting the subscriber from using Bundle"
    [Tags]    CRIT_P1_PCRF_4G_BUNDLE_MODULE
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_252
    [Documentation]    "To verify the behaviour of PCRF when 4G Only Bundle is exhausted in ongoing data session and subscriber opted in for 4G Service to use from account balance"
    [Tags]    CRIT_P1_PCRF_4G_BUNDLE_MODULE
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_253
    [Documentation]    "To verify the behaviour of PCRF when 4G Only Bundle is exhausted in ongoing data session and subscriber opted out of 4G Service to use from account balance"
    [Tags]    CRIT_P1_PCRF_4G_BUNDLE_MODULE
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_254
    [Documentation]    "To verify whether PCRF is sending negative CCA when 4G only Bundle is exhausted and latched in 4G RAT while subscriber opted out of 4G Service to use from account balance"
    [Tags]    CRIT_P1_PCRF_4G_BUNDLE_MODULE
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

*** keywords **