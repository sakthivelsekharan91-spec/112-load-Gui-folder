*** Settings ***
Documentation     PCRF_BILLSHOCK_MODULE_TEST_SUITE
Suite Setup       SUITE STARTUP
Test teardown     TEST STOP
Force Tags        PCRF_BILLSHOCK_MODULE
Default Tags      P2
Test Timeout      5 minutes
Library           Collections
Library           SSHLibrary
Library           OperatingSystem
Library           String
Library           BuiltIn
Library           DateTime
Library           DatabaseLibrary
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_MGTS_CONNECT.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_START_STOP.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_APP_CONNECT.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_SEAGULL_RUN.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_DB_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_LOGGING.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_CDR_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_SUITE_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_PCAP_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_SHELL_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_REMOTE_APP.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_TESTCASE_MODULE.robot
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_MAIN_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_LOGGING_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_CDR_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_DB_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_SEAGULL_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_PCAP_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_SHELL_COMMAND_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_REMOTE_APP_DETAILS.py

*** Variables ***


*** Test Cases ***

PCRF_AUTO_211
    [Documentation]    "To verify whether PCRF is installing proper rules when Subscriber has not set any threshold limit for home & starts a home data session"
    Set Test Variable    ${SHELL_PRE_CMD}       1
    [Tags]    CRIT_P1_BILLSHOCK
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_212
    [Documentation]    "To verify whether PCRF is installing proper rules when Subscriber has not set any threshold limit for roam & starts a roam data session"
    [Tags]    CRIT_P1_BILLSHOCK
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_213
    [Documentation]    "To verify whether PCRF is installing proper rules configured for bill-shock profile when Subscriber has set threshold limit for home with barring as consecutive action & starts a home data session"
    [Tags]    CRIT_P1_BILLSHOCK
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_214
    [Documentation]    "To verify whether PCRF is sending negative CCA when Subscriber has set threshold limit for home with barring as consecutive action & starts a home data session once threshold limit reached"
    [Tags]    CRIT_P1_BILLSHOCK
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_215
    [Documentation]    "To verify whether PCRF is installing proper rules when Subscriber has set threshold limit for home with barring as consecutive action & starts a roam data session"
    [Tags]    CRIT_P1_BILLSHOCK
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_216
    [Documentation]    "To verify whether PCRF is sending negative CCA when Subscriber has set threshold limit for roam with barring as consecutive action & starts a roam data session once threshold limit reached"
    [Tags]    CRIT_P1_BILLSHOCK
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_218
    [Documentation]    "To verify whether PCRF is installing proper rules configured for bill-shock profile when Subscriber has set threshold limit for home with apply different tariff as consecutive action & starts a home data session"
    [Tags]    CRIT_P1_BILLSHOCK
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_219
    [Documentation]    "To verify whether PCRF is installing QoS configured for the next regiong of the bill-shock profile having throttled speed when Subscriber has set threshold limit for home with Apply Different Tariff as consecutive action & starts a home data session once threshold limit reached"
    [Tags]    CRIT_P1_BILLSHOCK
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_220
    [Documentation]    "To verify whether PCRF is installing proper rules when Subscriber has set threshold limit for home with Apply Different Tariff  as consecutive action & starts a roam data session"
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_221
    [Documentation]    "To verify whether RRBS is triggering CHANGE_SPENDING_LIMIT request properly when Subscriberr has set threshold limit for home with Apply Different Tariff as consecutive action & crosses the limit in ongoing data session"
    [Tags]    CRIT_P1_BILLSHOCK
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_222
    [Documentation]    "To verify whether PCRF is installing proper rules configured for bill-shock profile when Subscriber has set threshold limit for home with Continue Data Service as consecutive action & starts a home data session"
    [Tags]    CRIT_P1_BILLSHOCK
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_223
    [Documentation]    "To verify whether PCRF is installing proper rules configured for bill-shock profile when Subscriber has set threshold limit for home with Continue Data Service as consecutive action & starts a home data session once threshold limit reached"
    [Tags]    CRIT_P1_BILLSHOCK
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_224
    [Documentation]    "To verify whether PCRF is installing proper rules configured for bill-shock profile when Subscriber has set threshold limit for home with Continue Data Service as consecutive action & starts a roam data session"
    [Tags]    CRIT_P1_BILLSHOCK
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_225
    [Documentation]    "To verify whether PCRF is installing proper rules configured for bill-shock profile when Subscriber has set threshold limit for roam with barring as consecutive action & starts a roam data session"
    [Tags]    CRIT_P1_BILLSHOCK
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}


PCRF_AUTO_226
    [Documentation]    "To verify whether PCRF is sending negative CCA when Subscriber has set threshold limit for roam with barring as consecutive action & starts a roam data session once threshold limit reached 
    [Tags]    CRIT_P1_BILLSHOCK
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}



PCRF_AUTO_227
    [Documentation]    "To verify whether PCRF is installing proper rules when Subscriber has set threshold limit for roam with barring as consecutive action & starts a home data session"
    [Tags]    CRIT_P1_BILLSHOCK
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}



PCRF_AUTO_228
    [Documentation]    "To verify whether PCRF is installing proper rules when Subscriber has set threshold limit for roam with barring as consecutive action & starts a home data session once roam threshold limit is reached"
    [Tags]    CRIT_P1_BILLSHOCK
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}



PCRF_AUTO_229
    [Documentation]    "To verify whether RRBS is triggering CHANGE_SPENDING_LIMIT request properly when Subscriberr has set threshold limit for roam with barring as consecutive action & crosses the limit in ongoing data session"
    [Tags]    CRIT_P1_BILLSHOCK
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}


PCRF_AUTO_230
    [Documentation]    "To verify whether PCRF is installing proper rules configured for bill-shock profile when Subscriber has set threshold limit for roam with apply different tariff as consecutive action & starts a roam data session"
    [Tags]    CRIT_P1_BILLSHOCK
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}


PCRF_AUTO_231
    [Documentation]    "To verify whether PCRF is installing QoS configured for the next regiong of the bill-shock profile having throttled speed when Subscriber has set threshold limit for roam with Apply Different Tariff as consecutive action & starts a roam data session once threshold limit reached"
    [Tags]    CRIT_P1_BILLSHOCK
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_232
    [Documentation]    "To verify whether PCRF is installing proper rules when Subscriber has set threshold limit for roam with Apply Different Tariff  as consecutive action & starts a home data session"
    [Tags]    CRIT_P1_BILLSHOCK
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_233
    [Documentation]    "To verify whether RRBS is triggering CHANGE_SPENDING_LIMIT request properly when Subscriberr has set threshold limit for roam with Apply Different Tariff as consecutive action & crosses the limit in ongoing data session"
    [Tags]    CRIT_P1_BILLSHOCK
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_234
    [Documentation]    "To verify whether PCRF is installing proper rules configured for bill-shock profile when Subscriber has set threshold limit for roam with Continue Data Service as consecutive action & starts a roam data session"
    [Tags]    CRIT_P1_BILLSHOCK
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_235
    [Documentation]    "To verify whether PCRF is installing proper rules configured for bill-shock profile when Subscriber has set threshold limit for roam with Continue Data Service as consecutive action & starts a roam data session once threshold limit reached"
    [Tags]    CRIT_P1_BILLSHOCK
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}


PCRF_AUTO_236
    [Documentation]    "To verify whether PCRF is installing proper rules configured for bill-shock profile when Subscriber has set threshold limit for roam with Continue Data Service as consecutive action & starts a home data session"
    [Tags]    CRIT_P1_BILLSHOCK
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

*** keywords **