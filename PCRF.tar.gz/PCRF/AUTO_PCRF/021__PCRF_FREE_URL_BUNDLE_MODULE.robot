*** Settings ***
Documentation     PCRF_FREE_URL_BUNDLE_MODULE
Suite Setup       SUITE STARTUP
Test teardown     TEST STOP
Force Tags        PCRF_FREE_URL_BUNDLE_MODULE
Default Tags      P2
Test Timeout      5 minutes
Library           Collections
Library           SSHLibrary
Library           OperatingSystem
Library           String
Library           BuiltIn
Library           DateTime
Library           DatabaseLibrary
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_MGTS_CONNECT.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_START_STOP.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_APP_CONNECT.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_SEAGULL_RUN.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_DB_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_LOGGING.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_CDR_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_SUITE_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_PCAP_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_SHELL_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_REMOTE_APP.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_TESTCASE_MODULE.robot
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_MAIN_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_LOGGING_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_CDR_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_DB_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_SEAGULL_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_PCAP_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_SHELL_COMMAND_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_REMOTE_APP_DETAILS.py

*** Variables ***


*** Test Cases ***

PCRF_AUTO_255
    [Documentation]    "To verify whether PCRF is installing Free Data URL along with Bundle URL upon receiving Initial Request."
    [Tags]    CRIT_P1_PCRF_FREE_URL_BUNDLE_MODULE
    Set Test Variable    ${SHELL_PRE_CMD}       1
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_256
    [Documentation]    "To verify whether Bundle Free Data is not get deducted when Subscriber is browsing Free Data URL and Threshold is not crossed."
    [Tags]    CRIT_P1_PCRF_FREE_URL_BUNDLE_MODULE
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_257
    [Documentation]    "To verify whether Bundle Free Data is  get deducted when Subscriber is browsing URL's other than Free Data URL and Threshold is not crossed."
    [Tags]    CRIT_P1_PCRF_FREE_URL_BUNDLE_MODULE
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_258
    [Documentation]    "To verify whether Bundle Free Data is  get deducted when Subscriber is browsing Free Data URL when Threshold is crossed."
    [Tags]    CRIT_P1_PCRF_FREE_URL_BUNDLE_MODULE
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_259
    [Documentation]    "To verify whether Subscriber account balance is not get deducted when Subscriber is browsing Free Data URL and Threshold is not reached while Bundle Free Data Exhausted."
    [Tags]    CRIT_P1_PCRF_FREE_URL_BUNDLE_MODULE
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_260
    [Documentation]    "To verify whether Subscriber account balance is get deducted when Subscriber is browsing Free Data URL while Threshold limit is reached and Bundle Free Data Exhausted."
    [Tags]    CRIT_P1_PCRF_FREE_URL_BUNDLE_MODULE
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_261
    [Documentation]    "To verify whether Subscriber account balance is  get deducted when Subscriber is browsing Free Data URL and Threshold is not reached while Bundle is expired."
    [Tags]    CRIT_P2_PCRF_FREE_URL_BUNDLE_MODULE
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_262
    [Documentation]    "To verify whether Subscriber account balance is  get deducted when Subscriber is browsing URL's other than Free Data URL while Threshold is not reached for Free Data URL and Bundle Free Data is exhausted."
    [Tags]    CRIT_P1_PCRF_FREE_URL_BUNDLE_MODULE
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}
