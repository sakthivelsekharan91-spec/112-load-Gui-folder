*** Settings ***
Documentation     CCA_IN_RRBS_FAILCAUSE
Suite Setup       SUITE STARTUP
Test teardown     TEST STOP
Force Tags        CCA_IN_RRBS_FAILCAUSE
Default Tags      P2
Test Timeout      5 minutes
Library           Collections
Library           SSHLibrary
Library           OperatingSystem
Library           String
Library           BuiltIn
Library           DateTime
Library           DatabaseLibrary
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_MGTS_CONNECT.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_START_STOP.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_APP_CONNECT.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_SEAGULL_RUN.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_DB_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_LOGGING.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_CDR_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_SUITE_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_PCAP_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_SHELL_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_REMOTE_APP.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_TESTCASE_MODULE.robot
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_MAIN_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_LOGGING_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_CDR_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_DB_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_SEAGULL_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_PCAP_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_SHELL_COMMAND_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_REMOTE_APP_DETAILS.py

*** Variables ***

${SHELL_ON_CALL_CMD}               1




*** Test Cases ***



PCRF_AUTO_268
    [Documentation]    "To verify that PCRF Sends the Negative CCA when RRBS sends Service not allowed Error to PCRF"
    [Tags]    P1_CCA_IN_RRBS_FAILCAUSE
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_269
    [Documentation]    "To verify that PCRF is sending the the configured Diameter errorcode in CCA for RRBS Errorcode when RRBS Sends Service not allowed Error"
    [Tags]    P1_CCA_IN_RRBS_FAILCAUSE
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_270
    [Documentation]    "To verify the Behaviour of PCRF when Redirecton is enabled for the when diameter Error code is not configured for the RRBS Error code"
    [Tags]    P1_CCA_IN_RRBS_FAILCAUSE
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_271
    [Documentation]    "To verify that PCRF is sending the the configured Diameter errorcode in CCA for RRBS Errorcode when Redirection is Enabled"
    [Tags]    P2_CCA_IN_RRBS_FAILCAUSE
    Set Test Variable    ${SHELL_PRE_CMD}       1
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_272
    [Documentation]    "To verify that PCRFis sending the the configured Diameter errorcode in CCA for RRBS Errorcode"
    [Tags]    P2_CCA_IN_RRBS_FAILCAUSE
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

*** keywords ***
