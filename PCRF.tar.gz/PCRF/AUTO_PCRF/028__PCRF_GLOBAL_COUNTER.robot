*** Settings ***
Documentation     PCRF_GLOBAL_COUNTER
Suite Setup       SUITE STARTUP
Test teardown     TEST STOP
Force Tags        PCRF_GLOBAL_COUNTER
Default Tags      P2
Test Timeout      5 minutes
Library           Collections
Library           SSHLibrary
Library           OperatingSystem
Library           String
Library           BuiltIn
Library           DateTime
Library           DatabaseLibrary
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_MGTS_CONNECT.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_START_STOP.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_APP_CONNECT.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_SEAGULL_RUN.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_DB_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_LOGGING.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_CDR_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_SUITE_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_PCAP_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_SHELL_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_REMOTE_APP.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_TESTCASE_MODULE.robot
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_MAIN_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_LOGGING_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_CDR_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_DB_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_SEAGULL_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_PCAP_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_SHELL_COMMAND_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_REMOTE_APP_DETAILS.py

*** Variables ***
${LOGGER_Validation}               1
${CDR_Validation}                  0
${PRE_DB_Validation}               1
${POST_DB_QUERY_Validation}        0
${SHELL_ON_CALL_CMD}               1



*** Test Cases ***

PCRF_AUTO_278
    [Documentation]    " To verify that RRBS is sending the Policy Counters to PCRF only once when Global Counter is attached for the bundle when the subscriber has the same bundles multiple times"
    [Tags]    P1_GLOBAL_COUNTER
    Set Test Variable    ${SHELL_PRE_CMD}    1
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_279
    [Documentation]    " To Verify the Behavior of RRBS when same Global Counter is attached for the Different Bundle code with same bundle Properties"
    [Tags]    P1_GLOBAL_COUNTER
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_280
    [Documentation]    " To verify that RRBS is sending the Policy Counters Details of the least expiry bundles among the multiple bundles with same bundle code & different Pocket id when Global Counter is attached for the bundle"
    [Tags]    P1_GLOBAL_COUNTER
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_281
    [Documentation]    " To verify that Behavior of RRBS when Subscriber has maximum count(20 Bundles) of the bundles allowed with same bundle code when Global Counter is configured for the bundle"
    [Tags]    P1_GLOBAL_COUNTER
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_282
    [Documentation]    " To verify that RRBS is sending the Policy Counter Details to PCRF for all the bundles when the subscriber has the different Bundles with Different Global counters attached for each Bundle"
    [Tags]    P1_GLOBAL_COUNTER
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_283
    [Documentation]    " To verify that Low speed region of the first bundle for which high speed policy counters sent initially to PCRF in the change spending limit request once the high speed quota of the all the bundles gets Exhausted when Global Counters"
    [Tags]    P1_GLOBAL_COUNTER
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_284
    [Documentation]    " To verify that RRBS is not sending Change Spending to PCRF when the high speed Quota of the first bundle gets exhausted when subscriber still has the high speed quota left out in the next bundle for the multiple bundles with global counters"
    [Tags]    P1_GLOBAL_COUNTER
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_285
    [Documentation]    " To verify the Behaviour when the global Counter is disabled at the Network level when Global counter id enabled for the Counter & Configured for the bundle"
    [Tags]    P1_GLOBAL_COUNTER
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}



*** keywords **
