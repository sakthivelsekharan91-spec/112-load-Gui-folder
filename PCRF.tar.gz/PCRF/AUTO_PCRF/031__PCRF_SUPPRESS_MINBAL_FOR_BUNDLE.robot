*** Settings ***
Documentation     PCRF_SUPPRESS_MINBAL_FOR_BUNDLE 
Suite Setup       SUITE STARTUP
Test teardown     TEST STOP
Force Tags        031__PCRF_SUPPRESS_MINBAL_FOR_BUNDLE 
Default Tags      P2
Test Timeout      5 minutes
Library           Collections
Library           SSHLibrary
Library           OperatingSystem
Library           String
Library           BuiltIn
Library           DateTime
Library           DatabaseLibrary
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_MGTS_CONNECT.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_START_STOP.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_APP_CONNECT.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_SEAGULL_RUN.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_DB_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_LOGGING.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_CDR_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_SUITE_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_PCAP_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_SHELL_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_REMOTE_APP.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_TESTCASE_MODULE.robot
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_MAIN_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_LOGGING_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_CDR_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_DB_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_SEAGULL_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_PCAP_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_SHELL_COMMAND_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_REMOTE_APP_DETAILS.py

*** Variables ***
${SHELL_ON_CALL_CMD}    1



*** Test Cases ***

PCRF_AUTO_290
    [Documentation]    "To verify that RRBS  send the Min Balance Counter to the PCRF when Account Balance less than the Min Balance when subscriber doesnot have any active bundles with SUPPRESS_MINBAL_FOR_BUNDLE enabled"
    [Tags]    P1_PCRF_REVALIDATION_TIME_AVP
    Set Test Variable    ${SHELL_PRE_CMD}    1
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_291
    [Documentation]    "To verify that RRBS doesnot send the Min Balance Counter to the PCRF when Account Balance less than the Min Balance threshold when Subscriber has the active Unlimted Bundle with SUPPRESS_MINBAL_FOR_BUNDLE enabled"
    [Tags]    P2_PCRF_REVALIDATION_TIME_AVP
    Set Test Variable    ${SHELL_PRE_CMD}    1
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_292
    [Documentation]    "To verify that RRBS sends the Min Balance Counter to the PCRF when Account Balance less than the Min Balance threshold when Subscriber has the active Unlimted Bundle with SUPPRESS_MINBAL_FOR_BUNDLE Disabled"
    [Tags]    P1_PCRF_REVALIDATION_TIME_AVP
    Set Test Variable    ${SHELL_PRE_CMD}    1
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_293
    [Documentation]    "To verify that RRBS is not sending the Min Balance Counter to the PCRF when Account Balance less than the Min Balance threshold when Subscriber has the active Limited Bundle with bundle free units SUPPRESS_MINBAL_FOR_BUNDLE Enabled"
    [Tags]    P1_PCRF_REVALIDATION_TIME_AVP
    Set Test Variable    ${SHELL_PRE_CMD}    1
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_294
    [Documentation]    "To verify that RRBS is sending the Min Balance Counter to the PCRF when Account Balance less than the Min Balance threshold when Subscriber has the active Limited Bundle without bundle free units SUPPRESS_MINBAL_FOR_BUNDLE Enabled and UPON_EXHAUST_IGNORE is enabled"
    [Tags]    P1_PCRF_REVALIDATION_TIME_AVP
    Set Test Variable    ${SHELL_PRE_CMD}    1
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_295
    [Documentation]    "To verify the behaviour of the RRBS application when the free data in the Limited bundle gets exhaused in the ongoing data session SUPPRESS_MINBAL_FOR_BUNDLE Enabled"
    [Tags]    P1_PCRF_REVALIDATION_TIME_AVP
    Set Test Variable    ${SHELL_PRE_CMD}    1
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_296
    [Documentation]    "To verify that RRBS is sending Tariff Policy Counter to the PCRF when Account Balance less than the Min Balance threshold when Subscriber has the active Limited Bundle without bundle free units SUPPRESS_MINBAL_FOR_BUNDLE Enabled and UPON_EXHAUST_IGNORE is disabled"
    [Tags]    P1_PCRF_REVALIDATION_TIME_AVP
    Set Test Variable    ${SHELL_PRE_CMD}    1
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_297
    [Documentation]    "To verify that RRBS is sending the Min Balance Counter to the PCRF when Account Balance less than the Min Balance threshold when Subscriber has the active Limited Bundle with bundle free units SUPPRESS_MINBAL_FOR_BUNDLE Enabled and UPON_EXHAUST_IGNORE is enabled"
    [Tags]    P2_PCRF_REVALIDATION_TIME_AVP
    Set Test Variable    ${SHELL_PRE_CMD}    1
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

*** keywords **
