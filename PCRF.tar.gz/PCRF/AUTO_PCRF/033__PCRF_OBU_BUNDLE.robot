*** Settings ***
Documentation     PCRF_OBU_BUNDLE
Suite Setup       SUITE STARTUP
Test teardown     TEST STOP
Force Tags        PCRF_OBU_BUNDLE 
Default Tags      P2
Test Timeout      5 minutes
Library           Collections
Library           SSHLibrary
Library           OperatingSystem
Library           String
Library           BuiltIn
Library           DateTime
Library           DatabaseLibrary
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_MGTS_CONNECT.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_START_STOP.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_APP_CONNECT.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_SEAGULL_RUN.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_DB_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_LOGGING.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_CDR_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_SUITE_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_PCAP_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_SHELL_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_REMOTE_APP.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_TESTCASE_MODULE.robot
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_MAIN_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_LOGGING_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_CDR_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_DB_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_SEAGULL_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_PCAP_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_SHELL_COMMAND_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_REMOTE_APP_DETAILS.py

*** Variables ***
${SHELL_ON_CALL_CMD}    1



*** Test Cases ***

PCRF_AUTO_299
    [Documentation]    "To verify that RRBS sends only the Policy Counters of Bundle When OBU Restriction is Enabled for the Bundle"
    [Tags]    P1_PCRF_OBU_BUNDLEP
    Set Test Variable    ${SHELL_PRE_CMD}    1
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_300
    [Documentation]    "To verify that RRBS sends only the Counter Details of the Bundle when OBU Restriction is Enabled for the Network Level"
    [Tags]    P2_PCRF_OBU_BUNDLE
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_301
    [Documentation]    "To verify the RRBS sends Policy Counters of Bundle & Traiff to the PCRF when the Subscriber has Opted to allow from the Tariff after the Bundle Exhaust"
    [Tags]    P1_PCRF_OBU_BUNDLE
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_302
    [Documentation]    "To Verify that the PCRF Removes Rules of the Bundle when the Bundle Gets Exhaust in the ongoing session foer which OBU Restiction is Enabeled"
    [Tags]    P1_PCRF_OBU_BUNDLE
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_303
    [Documentation]    "To Verify that PCRF removes the Bundle Rule & Installs the Tariff Rule when the Bundle gets exhaust in the on going session for which subscriber has opted to Allow the Account Balance"
    [Tags]    P1_PCRF_OBU_BUNDLE
    Set Test Variable    ${SHELL_PRE_CMD}    1
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_304
    [Documentation]    "To Verify that RRBS sends the Policy Counters of all the Bundles except Traiff when the Subscriber has the Multiple Bundle for which OBU is restricted for Both the Bundle"
    [Tags]    P1_PCRF_OBU_BUNDLE
    Set Test Variable    ${SHELL_PRE_CMD}    1
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_305
    [Documentation]    "To Verify that RRBS sends the Policy Counters of all the Bundles and  Traiff when the Subscriber has the Multiple Bundle for which one bundle has OBU Restiction & other has to allow OBU"
    [Tags]    P1_PCRF_OBU_BUNDLE
    Set Test Variable    ${SHELL_PRE_CMD}    1
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_306
    [Documentation]    "To verify that RRBS send only the Bundle Policy Counters to PCRF when the Subscriber has the Multiple Bundles out of which one Bundle has the Pay G restiction other bundle does not have any preference"
    [Tags]    P2_PCRF_OBU_BUNDLE
    Set Test Variable    ${SHELL_PRE_CMD}    1
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_307
    [Documentation]    "To verify that PCRF Removes the Rules of the Both the Bundles and does not install the rules of Tariff when both the Bundle allowance gets exhausted"
    [Tags]    P2_PCRF_OBU_BUNDLE
    Set Test Variable    ${SHELL_PRE_CMD}    1
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}


*** keywords **
