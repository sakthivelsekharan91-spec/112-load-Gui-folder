*** Settings ***
Documentation     PCRF_SUPPRESS_MINBAL_COUNTER_VALIDATION
Suite Setup       SUITE STARTUP
Test teardown     TEST STOP
Force Tags        PCRF_SUPPRESS_MINBAL_COUNTER_VALIDATION
Default Tags      P2
Test Timeout      5 minutes
Library           Collections
Library           SSHLibrary
Library           OperatingSystem
Library           String
Library           BuiltIn
Library           DateTime
Library           DatabaseLibrary
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_MGTS_CONNECT.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_START_STOP.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_APP_CONNECT.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_SEAGULL_RUN.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_DB_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_LOGGING.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_CDR_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_SUITE_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_PCAP_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_SHELL_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_REMOTE_APP.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_TESTCASE_MODULE.robot
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_MAIN_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_LOGGING_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_CDR_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_DB_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_SEAGULL_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_PCAP_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_SHELL_COMMAND_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_REMOTE_APP_DETAILS.py

*** Variables ***
${SHELL_ON_CALL_CMD}    1



*** Test Cases ***

PCRF_AUTO_314
    [Documentation]    "To verify that Min Balance counter is sent to PCRF interface when the subscriber has reached the Counter level threshold quota even though subscriber has the Bundle Allowance"
    [Tags]    P1_PCRF_SUPPRESS_MINBAL_COUNTER_VALIDATION
    Set Test Variable    ${SHELL_PRE_CMD}    1
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_315
    [Documentation]    "To verify that RRBS is sending the Min Balance Counter to the PCRF interface when Subscriber has  Account Balance less than the Min Balance when Subscriber has not reached the Bundle Threshold  with 0 as  bundle allowance"
    [Tags]    P2_PCRF_SUPPRESS_MINBAL_COUNTER_VALIDATION
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_316
    [Documentation]    "To verify that RRBS sends the Tariff Counter to the PCRF interface when Subscriber has the Bundle allowance with Upon_Exhaust_Ignore enabled when counter level threshold not reached for the Bundle"
    [Tags]    P1_PCRF_SUPPRESS_MINBAL_COUNTER_VALIDATION
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_317
    [Documentation]    "To Verify that RRBS considers the Bundle with allowance & sends the Tariff Counter to the PCRF with the subscriber has one of the Bundle with the Counter Limit Reached other Counter not Reached in Multiple Bundle Case"
    [Tags]    P1_PCRF_SUPPRESS_MINBAL_COUNTER_VALIDATION
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_318
    [Documentation]    "To Verify that RRBS considers the Bundle with allowance & sends the Tariff Counter to the PCRF with the subscriber has one of the Bundle with allowance Exhausted other with out the Counter not yet Reached"
    [Tags]    P1_PCRF_SUPPRESS_MINBAL_COUNTER_VALIDATION
    Set Test Variable    ${SHELL_PRE_CMD}    1
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_319
    [Documentation]    "To verify that RRBS sends the Min Balance Counter to PCRF when Subscriber has the Multiple Bundle with counter Reached for All the bundles"
    [Tags]    P1_PCRF_SUPPRESS_MINBAL_COUNTER_VALIDATION
    Set Test Variable    ${SHELL_PRE_CMD}    1
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

*** keywords **
