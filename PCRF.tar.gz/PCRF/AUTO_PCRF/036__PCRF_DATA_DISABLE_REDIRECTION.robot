*** Settings ***
Documentation     PCRF_DATA_DISABLE_REDIRECTION
Suite Setup       SUITE STARTUP
Test teardown     TEST STOP
Force Tags        PCRF_DATA_DISABLE_REDIRECTION
Default Tags      P2
Test Timeout      5 minutes
Library           Collections
Library           SSHLibrary
Library           OperatingSystem
Library           String
Library           BuiltIn
Library           DateTime
Library           DatabaseLibrary
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_MGTS_CONNECT.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_START_STOP.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_APP_CONNECT.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_SEAGULL_RUN.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_DB_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_LOGGING.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_CDR_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_SUITE_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_PCAP_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_SHELL_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_REMOTE_APP.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_TESTCASE_MODULE.robot
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_MAIN_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_LOGGING_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_CDR_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_DB_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_SEAGULL_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_PCAP_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_SHELL_COMMAND_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_REMOTE_APP_DETAILS.py

*** Variables ***
${SHELL_ON_CALL_CMD}    1



*** Test Cases ***

PCRF_AUTO_320
    [Documentation]    "To verify whether subscriber is re-directed to Top-Up portal when Subscriber when Data Service is Disabled at the Life level of the Subscriber"
    [Tags]    P1_PCRF_DATA_DISABLE_REDIRECTION
    Set Test Variable    ${SHELL_PRE_CMD}    1
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_321
    [Documentation]    "To verify whether subscriber is re-directed to Top-Up portal when Subscriber when Data Service is Disabled for the Subscriber in Sub Service"
    [Tags]    P2_PCRF_DATA_DISABLE_REDIRECTION
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_322
    [Documentation]    "To verify whether subscriber is re-directed to Top-Up portal when Subscriber when Data Service is Disabled for the Network"
    [Tags]    P1_PCRF_DATA_DISABLE_REDIRECTION
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_323
    [Documentation]    "To Verify Wheather the Subscriber is Redirected to the Top up  when  Subscriber is not Activated"
    [Tags]    P1_PCRF_DATA_DISABLE_REDIRECTION
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_324
    [Documentation]    "To Verify Wheather the Subscriber is Redirected to the Top up  when  RRBS sends Roam Zone not found"
    [Tags]    P1_PCRF_DATA_DISABLE_REDIRECTION
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}
*** keywords **
