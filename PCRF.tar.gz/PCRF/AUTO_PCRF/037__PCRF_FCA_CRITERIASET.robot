*** Settings ***
Documentation     PCRF_FCA_CRITERIASET
Suite Setup       SUITE STARTUP
Test teardown     TEST STOP
Force Tags        PCRF_FCA_CRITERIASET
Default Tags      P2
Test Timeout      5 minutes
Library           Collections
Library           SSHLibrary
Library           OperatingSystem
Library           String
Library           BuiltIn
Library           DateTime
Library           DatabaseLibrary
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_MGTS_CONNECT.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_START_STOP.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_APP_CONNECT.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_SEAGULL_RUN.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_DB_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_LOGGING.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_CDR_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_SUITE_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_PCAP_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_SHELL_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_REMOTE_APP.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_TESTCASE_MODULE.robot
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_MAIN_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_LOGGING_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_CDR_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_DB_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_SEAGULL_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_PCAP_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_SHELL_COMMAND_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_REMOTE_APP_DETAILS.py

*** Variables ***

${SHELL_ON_CALL_CMD}               1


*** Test Cases ***
PCRF_AUTO_325
    [Documentation]   To Verify that RRBS Application is sending the FCA_PROMOTION_REQUEST and FCA_PROMOTION_ALLOWANCE Notification to USSD Application when subscriber making first call in Home Region(Account balance) with Fca Promotion model as criteria set and criteria as sim face value 
    [Tags]    P1_PCRF_FCA_CRITERIASET
    Set Test Variable    ${SHELL_PRE_CMD}    1
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_326
    [Documentation]    To Verify that RRBS Application is sending the FCA_PROMOTION_REQUEST and FCA_PROMOTION_ALLOWANCE Notification to USSD Application when subscriber making first call in Home Region(Account balance) with Fca Promotion model as criteria set and criteria as ICCID(sim number)
    [Tags]    P1_PCRF_FCA_CRITERIASET
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_327
    [Documentation]     To Verify that RRBS Application is sending the FCA_PROMOTION_REQUEST and FCA_PROMOTION_ALLOWANCE Notification to USSD Application when subscriber making first call in Home Region(Account balance) with Fca Promotion model as criteria set and criteria as validity period
    [Tags]    P1_PCRF_FCA_CRITERIASET
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_328
    [Documentation]   To Verify that RRBS Application is sending the FCA_PROMOTION_REQUEST and FCA_PROMOTION_ALLOWANCE Notification to USSD Application when subscriber making first call in Home Region(Account balance) with Fca Promotion model as criteria set and criteria as sim face value,ICCID,validity period. 
    [Tags]    P1_PCRF_FCA_CRITERIASET
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_329
    [Documentation]   To Verify that RRBS Application is sending the FCA_PROMOTION_REQUEST and FCA_PROMOTION_ALLOWANCE Notification to USSD Application when subscriber making first call in Roam Region(Account balance) with Fca Promotion model as criteria set and criteria as sim face value 
    [Tags]    P1_PCRF_FCA_CRITERIASET
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_330
    [Documentation]    To Verify that RRBS Application is sending the FCA_PROMOTION_REQUEST and FCA_PROMOTION_ALLOWANCE Notification to USSD Application when subscriber making first call in Roam Region(Account balance) with Fca Promotion model as criteria set and criteria as ICCID(sim number)
    [Tags]    P1_PCRF_FCA_CRITERIASET
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_331
    [Documentation]     To Verify that RRBS Application is sending the FCA_PROMOTION_REQUEST and FCA_PROMOTION_ALLOWANCE Notification to USSD Application when subscriber making first call in Roam Region(Account balance) with Fca Promotion model as criteria set and criteria as validity period
    [Tags]    P1_PCRF_FCA_CRITERIASET
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_332
    [Documentation]   To Verify that RRBS Application is sending the FCA_PROMOTION_REQUEST and FCA_PROMOTION_ALLOWANCE Notification to USSD Application when subscriber making first call in Roam Region(Account balance) with Fca Promotion model as criteria set and criteria as sim face value,ICCID,validity period. 
    [Tags]    P1_PCRF_FCA_CRITERIASET
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_333
    [Documentation]   To Verify that RRBS Application is sending the FCA_PROMOTION_REQUEST and FCA_PROMOTION_ALLOWANCE Notification to USSD Application when subscriber making first call in Home Region(Bundle call) with Fca Promotion model as criteria set and criteria as sim face value 
    [Tags]    P1_PCRF_FCA_CRITERIASET
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_334
    [Documentation]    To Verify that RRBS Application is sending the FCA_PROMOTION_REQUEST and FCA_PROMOTION_ALLOWANCE Notification to USSD Application when subscriber making first call in Home Region(Bundle call) with Fca Promotion model as criteria set and criteria as ICCID
    [Tags]    P1_PCRF_FCA_CRITERIASET
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_335
    [Documentation]     To Verify that RRBS Application is sending the FCA_PROMOTION_REQUEST and FCA_PROMOTION_ALLOWANCE Notification to USSD Application when subscriber making first call in Home Region(Bundle call) with Fca Promotion model as criteria set and criteria as validity period
    [Tags]    P1_PCRF_FCA_CRITERIASET
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_336
    [Documentation]   To Verify that RRBS Application is sending the FCA_PROMOTION_REQUEST and FCA_PROMOTION_ALLOWANCE Notification to USSD Application when subscriber making first call in Home Region(Bundle call) with Fca Promotion model as criteria set and criteria as sim face value,ICCID,validity period. 
    [Tags]    P1_PCRF_FCA_CRITERIASET
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_337
    [Documentation]   To Verify that RRBS Application is sending the FCA_PROMOTION_REQUEST and FCA_PROMOTION_ALLOWANCE Notification to USSD Application when subscriber making first call in Roam Region(Bundle call) with Fca Promotion model as criteria set and criteria as sim face value 
    [Tags]    P1_PCRF_FCA_CRITERIASET
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_338
    [Documentation]    To Verify that RRBS Application is sending the FCA_PROMOTION_REQUEST and FCA_PROMOTION_ALLOWANCE Notification to USSD Application when subscriber making first call in Roam Region(Bundle call) with Fca Promotion model as criteria set and criteria as ICCID(sim number)
    [Tags]    P1_PCRF_FCA_CRITERIASET
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_339
    [Documentation]     To Verify that RRBS Application is sending the FCA_PROMOTION_REQUEST and FCA_PROMOTION_ALLOWANCE Notification to USSD Application when subscriber making first call in Roam Region(Bundle call) with Fca Promotion model as criteria set and criteria as validity period
    [Tags]    P1_PCRF_FCA_CRITERIASET
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_340
    [Documentation]   To Verify that RRBS Application is sending the FCA_PROMOTION_REQUEST and FCA_PROMOTION_ALLOWANCE Notification to USSD Application when subscriber making first call in Roam Region(Bundle call) with Fca Promotion model as criteria set and criteria as sim face value,ICCID,validity period. 
    [Tags]    P1_PCRF_FCA_CRITERIASET
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_341
    [Documentation]   To Verify that RRBS Application is not sending the FCA_PROMOTION_REQUEST and FCA_PROMOTION_ALLOWANCE Notification to USSD Application when subscriber making first call in Home Region(Account balance) with Fca Promotion model as criteria set and criteria as sim face value,ICCID,validity period not matched. 
    [Tags]    P1_PCRF_FCA_CRITERIASET
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_342
    [Documentation]   To Verify that RRBS Application is not sending the FCA_PROMOTION_REQUEST and FCA_PROMOTION_ALLOWANCE Notification to USSD Application when subscriber making first call in Home Region(Bundle call) with Fca Promotion model as criteria set and criteria as sim face value,ICCID,validity period not matched. 
    [Tags]    P1_PCRF_FCA_CRITERIASET
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_343
    [Documentation]   To Verify that RRBS Application is not sending the FCA_PROMOTION_REQUEST and FCA_PROMOTION_ALLOWANCE Notification to USSD Application when subscriber making first call in Roam Region(Account balance) with Fca Promotion model as criteria set and criteria as sim face value,ICCID,validity period not matched. 
    [Tags]    P1_PCRF_FCA_CRITERIASET
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_344
    [Documentation]   To Verify that RRBS Application is not sending the FCA_PROMOTION_REQUEST and FCA_PROMOTION_ALLOWANCE Notification to USSD Application when subscriber making first call in Roam Region(Bundle call) with Fca Promotion model as criteria set and criteria as sim face value,ICCID,validity period not matched. 
    [Tags]    P1_PCRF_FCA_CRITERIASET
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_345
    [Documentation]   To Verify that RRBS Application is not  sending the FCA_PROMOTION_REQUEST and FCA_PROMOTION_ALLOWANCE Notification to USSD Application when subscriber making first call in Home Region(Account balance) with Fca Promotion model as Traditional model  
    [Tags]    P1_PCRF_FCA_CRITERIASET
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_346
    [Documentation]   To Verify that RRBS Application is not  sending the FCA_PROMOTION_REQUEST and FCA_PROMOTION_ALLOWANCE Notification to USSD Application when subscriber making first call in Home Region(Bundle call) with Fca Promotion model as Traditional model  
    [Tags]    P1_PCRF_FCA_CRITERIASET
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_347
    [Documentation]   To Verify that RRBS Application is not  sending the FCA_PROMOTION_REQUEST and FCA_PROMOTION_ALLOWANCE Notification to USSD Application when subscriber making first call in Roam Region(Account balance) with Fca Promotion model as Traditional model  
    [Tags]    P1_PCRF_FCA_CRITERIASET
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}



*** Keywords ***
