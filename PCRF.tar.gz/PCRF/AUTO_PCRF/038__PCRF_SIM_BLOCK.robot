*** Settings ***
Documentation     PCRF_SIM_BLOCK
Suite Setup       SUITE STARTUP
Test Teardown     TEST STOP
Force Tags        PCRF_SIM_BLOCK
Default Tags      P2
Test Timeout      5 minutes
Library           Collections
Library           SSHLibrary
Library           OperatingSystem
Library           String
Library           BuiltIn
Library           DateTime
Library           DatabaseLibrary
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_MGTS_CONNECT.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_START_STOP.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_APP_CONNECT.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_SEAGULL_RUN.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_DB_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_LOGGING.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_CDR_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_SUITE_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_PCAP_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_SHELL_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_REMOTE_APP.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_TESTCASE_MODULE.robot
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_MAIN_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_LOGGING_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_CDR_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_DB_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_SEAGULL_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_PCAP_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_SHELL_COMMAND_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_REMOTE_APP_DETAILS.py

*** Variables ***
${LOGGER_Validation}    1
${CDR_Validation}    1
${PRE_DB_Validation}    1
${POST_DB_QUERY_Validation}    1
${SHELL_ON_CALL_CMD}    1

*** Test Cases ***
PCRF_AUTO_348
    [Documentation]    To Verify that subscriber is able to browse from the Bundle when Data service is enabled for permenent SIM Block
    [Tags]    P1_PCRF_SIM_BLOCK
    Set Test Variable    ${SHELL_PRE_CMD}    1
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_349
    [Documentation]    To Verify that Subscriber is Redirected with Redirection indicator for Bundle Data call when Data service is Disabled for permenent SIM Block
    [Tags]    P1_PCRF_SIM_BLOCK
    Set Test Variable    ${SHELL_PRE_CMD}    1
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_350
    [Documentation]    To Verify that subscriber is able to browse from the Bundle when Data service is enabled for Fraudant SIM Block
    [Tags]    P1_PCRF_SIM_BLOCK
    Set Test Variable    ${SHELL_PRE_CMD}    1
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_351
    [Documentation]    To Verify that Subscriber is Redirected with Redirection indicator for Bundle Data call when Data service is Disabled for Fraudant SIM Block
    [Tags]    P1_PCRF_SIM_BLOCK
    Set Test Variable    ${SHELL_PRE_CMD}    1
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_352
    [Documentation]    To Verify that subscriber is able to browse from Account Balance when Data service is enabled for permenent SIM Block
    [Tags]    P1_PCRF_SIM_BLOCK
    Set Test Variable    ${SHELL_PRE_CMD}    1
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_353
    [Documentation]    To Verify that Subscriber is Redirected with Redirection indicator for Chargable Data call when Data service is Disabled for permenent SIM Block
    [Tags]    P1_PCRF_SIM_BLOCK
    Set Test Variable    ${SHELL_PRE_CMD}    1
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_354
    [Documentation]    To Verify that subscriber is able to browse from the Account Balance when Data service is enabled for Fraudant SIM Block
    [Tags]    P1_PCRF_SIM_BLOCK
    Set Test Variable    ${SHELL_PRE_CMD}    1
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_355
    [Documentation]    To Verify that Subscriber is Redirected with Redirection indicator for Chargable Data call when Data service is Disabled for Fraudant SIM Block
    [Tags]    P1_PCRF_SIM_BLOCK
    Set Test Variable    ${SHELL_PRE_CMD}    1
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_356
    [Documentation]    To Verify that subscriber is able to browse from the Bundle when Data service is enabled for permenent SIM Block in Roam
    [Tags]    P1_PCRF_SIM_BLOCK
    Set Test Variable    ${SHELL_PRE_CMD}    1
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_357
    [Documentation]    To Verify that Subscriber is Redirected with Redirection indicator for Bundle Data call when Data service is Disabled for permenent SIM Block in Local Roam
    [Tags]    P1_PCRF_SIM_BLOCK
    Set Test Variable    ${SHELL_PRE_CMD}    1
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_358
    [Documentation]    To Verify that subscriber is able to browse from the Bundle when Data service is enabled for Fraudant SIM Block in Roam
    [Tags]    P1_PCRF_SIM_BLOCK
    Set Test Variable    ${SHELL_PRE_CMD}    1
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_359
    [Documentation]    To Verify that Subscriber is Redirected with Redirection indicator for Bundle Data call when Data service is Disabled for Fraudant SIM Block in Local Roam
    [Tags]    P1_PCRF_SIM_BLOCK
    Set Test Variable    ${SHELL_PRE_CMD}    1
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_360
    [Documentation]    To Verify that Family Child Subscriber is able to Browse from the Family Bundle when Data Service is blocked as fraudulent for the Parent Subscriber and Data Service is Enabled as Temporay Block for the Child Subscriber
    [Tags]    P1_PCRF_SIM_BLOCK
    Set Test Variable    ${SHELL_PRE_CMD}    1
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_361
    [Documentation]    To Verify that Family Parent Subscriber is able to Browse from the Family Bundle when Data Service is blocked as fraudulent for the Child Subscriber and Data Service is Enabled as Temporay Block for the Parent Subscriber
    [Tags]    P1_PCRF_SIM_BLOCK
    Set Test Variable    ${SHELL_PRE_CMD}    1
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_362
    [Documentation]    To verify that Data service is aloowed for the Family Subscriber When data service is enabled for fraudulent both child & Parent Subscriber
    [Tags]    P1_PCRF_SIM_BLOCK
    Set Test Variable    ${SHELL_PRE_CMD}    1
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_363
    [Documentation]    To verify that Data service is aloowed for the Family Subscriber When data service is enabled for fraudulent both child & Parent Subscriber
    [Tags]    P1_PCRF_SIM_BLOCK
    Set Test Variable    ${SHELL_PRE_CMD}    1
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_364
    [Documentation]    To Verify that Subscriber is able to browse data when SIM status is marked as 0 when data service is disabled for for fraudulent Subscribers
    [Tags]    P1_PCRF_SIM_BLOCK
    Set Test Variable    ${SHELL_PRE_CMD}    1
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_365
    [Documentation]    To Verify that Subscriber is able to browse data when SIM status is marked as 0 when data service is disabled for for Permanent Block Subscribers
    [Tags]    P1_PCRF_SIM_BLOCK
    Set Test Variable    ${SHELL_PRE_CMD}    1
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_366
    [Documentation]    To Verify that Subscriber is able to browse data when SIM status is marked as 1 when data service is enabled for for fraudulent Subscribers
    [Tags]    P1_PCRF_SIM_BLOCK
    Set Test Variable    ${SHELL_PRE_CMD}    1
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_367
    [Documentation]    To Verify that Subscriber is able to browse data when SIM status is marked as 1 when data service is enabled for for Permanent Block Subscribers
    [Tags]    P1_PCRF_SIM_BLOCK
    Set Test Variable    ${SHELL_PRE_CMD}    1
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

*** Keywords ***
