*** Settings ***
Documentation     PCRF_FRR_4625
Suite Setup       SUITE STARTUP
Test Teardown     TEST STOP
Force Tags        PCRF_FRR_4625
Default Tags      P2
Test Timeout      5 minutes
Library           Collections
Library           SSHLibrary
Library           OperatingSystem
Library           String
Library           BuiltIn
Library           DateTime
Library           DatabaseLibrary
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_MGTS_CONNECT.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_START_STOP.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_APP_CONNECT.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_SEAGULL_RUN.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_DB_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_LOGGING.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_CDR_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_SUITE_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_PCAP_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_SHELL_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_REMOTE_APP.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_TESTCASE_MODULE.robot
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_MAIN_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_LOGGING_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_CDR_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_DB_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_SEAGULL_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_PCAP_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_SHELL_COMMAND_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_REMOTE_APP_DETAILS.py

*** Variables ***
${LOGGER_Validation}    1
${CDR_Validation}    1
${PRE_DB_Validation}    1
${POST_DB_QUERY_Validation}    1
${SHELL_ON_CALL_CMD}    1

*** Test Cases ***
PCRF_AUTO_368
    [Documentation]    To verify PCRF application behaviour when CHARGE_RULE_INSTALL AVP is not sent in Credit-Control-Answer when disabling CHARGE_RULE_INSTALL in PCRF SMP.
    [Tags]    P1_PCRF_FRR_4625
    Set Test Variable    ${SHELL_PRE_CMD}    1
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_369
    [Documentation]    To verify PCRF application behaviour when CHARGE_RULE_INSTALL AVP is sent in Credit-Control-Answer when enabling CHARGE_RULE_INSTALL in PCRF SMP
    [Tags]    P1_PCRF_FRR_4625
    Set Test Variable    ${SHELL_PRE_CMD}    1
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_370
    [Documentation]    To verify PCRF application behaviour when CHARGE_RULE_REMOVE AVP is sent in Credit-Control-Answer when enabling CHARGE_RULE_REMOVE in PCRF SMP
    [Tags]    P1_PCRF_FRR_4625
    Set Test Variable    ${SHELL_PRE_CMD}    1
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_371
    [Documentation]    To verify PCRF application behaviour when CHARGE_RULE_REMOVE AVP is not sent in Credit-Control-Answer when disabling CHARGE_RULE_REMOVE in PCRF SMP
    [Tags]    P1_PCRF_FRR_4625
    Set Test Variable    ${SHELL_PRE_CMD}    1
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_372
    [Documentation]    To verify PCRF application behaviour when CHARGE_INFORMATION AVP is sent in Credit-Control-Answer when enabling CHARGE_INFORMATION in PCRF SMP
    [Tags]    P1_PCRF_FRR_4625
    Set Test Variable    ${SHELL_PRE_CMD}    1
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_373
    [Documentation]    To verify PCRF application behaviour when CHARGE_INFORMATION AVP is not sent in Credit-Control-Answer when disabling CHARGE_INFORMATION in PCRF SMP
    [Tags]    P1_PCRF_FRR_4625
    Set Test Variable    ${SHELL_PRE_CMD}    1
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_374
    [Documentation]    To verify PCRF application behaviour when CHARGE_RULE_REMOVE AVP is sent in RAR when enabling CHARGE_RULE_REMOVE in PCRF SMP
    [Tags]    P1_PCRF_FRR_4625
    Set Test Variable    ${SHELL_PRE_CMD}    1
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_375
    [Documentation]    To verify PCRF application behaviour when CHARGE_RULE_REMOVE AVP is not sent in RAR when disabling CHARGE_RULE_REMOVE in PCRF SMP
    [Tags]    P1_PCRF_FRR_4625
    Set Test Variable    ${SHELL_PRE_CMD}    1
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_376
    [Documentation]    To verify PCRF application behaviour when DEFAULT_EPS_BEARER_QOS AVP is sent in RAR when enabling DEFAULT_EPS_BEARER_QOS AVP in PCRF SMP
    [Tags]    P1_PCRF_FRR_4625
    Set Test Variable    ${SHELL_PRE_CMD}    1
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_377
    [Documentation]    To verify PCRF application behaviour when DEFAULT_EPS_BEARER_QOS AVP AVP is not sent in RAR when disabling DEFAULT_EPS_BEARER_QOS AVP in PCRF SMP
    [Tags]    P1_PCRF_FRR_4625
    Set Test Variable    ${SHELL_PRE_CMD}    1
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_378
    [Documentation]    To verify PCRF application behaviour when DEFAULT_EPS_BEARER_QOS,CHARGE_RULE_REMOVE AVP,CHARGE_INFORMATION AVP and CHARGE_RULE_INSTALL AVP is sent in CCA and RAR when enabling DEFAULT_EPS_BEARER_QOS,CHARGE_RULE_REMOVE AVP,CHARGE_INFORMATION AVP and CHARGE_RULE_INSTALL AVP in PCRF SMP
    [Tags]    P1_PCRF_FRR_4625
    Set Test Variable    ${SHELL_PRE_CMD}    1
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_379
    [Documentation]    To verify PCRF application behaviour when DEFAULT_EPS_BEARER_QOS,CHARGE_RULE_REMOVE AVP,CHARGE_INFORMATION AVP and CHARGE_RULE_INSTALL AVP is sent in CCA and RAR when disabling DEFAULT_EPS_BEARER_QOS,CHARGE_RULE_REMOVE AVP,CHARGE_INFORMATION AVP and CHARGE_RULE_INSTALL AVP in PCRF SMP
    [Tags]    P1_PCRF_FRR_4625
    Set Test Variable    ${SHELL_PRE_CMD}    1
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}


*** Keywords ***
