*** Settings ***
Documentation     PCRF_FRR_4683
Suite Setup       SUITE STARTUP
Test Teardown     TEST STOP
Force Tags        PCRF_FRR_4683
Default Tags      P2
Test Timeout      5 minutes
Library           Collections
Library           SSHLibrary
Library           OperatingSystem
Library           String
Library           BuiltIn
Library           DateTime
Library           DatabaseLibrary
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_MGTS_CONNECT.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_START_STOP.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_APP_CONNECT.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_SEAGULL_RUN.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_DB_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_LOGGING.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_CDR_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_SUITE_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_PCAP_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_SHELL_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_REMOTE_APP.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_TESTCASE_MODULE.robot
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_MAIN_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_LOGGING_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_CDR_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_DB_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_SEAGULL_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_PCAP_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_SHELL_COMMAND_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_REMOTE_APP_DETAILS.py

*** Variables ***
${LOGGER_Validation}    1
${CDR_Validation}    1
${PRE_DB_Validation}    1
${POST_DB_QUERY_Validation}    1
${SHELL_ON_CALL_CMD}    1

*** Test Cases ***
PCRF_AUTO_380
    [Documentation]    To Verify PCRF application behaviour on receiving APN  that is is configured in THIRD PARTY APN Billing system for SDFT model and comming MCC matches with Home_MCC table
    [Tags]    P1_PCRF_FRR_4683
    Set Test Variable    ${SHELL_PRE_CMD}    1
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_381
    [Documentation]    "To Verify PCRF application behaviour on receiving APN  that is is configured in THIRD PARTY APN Billing system for SDFT model and comming MCC-MNC matches with Home_MCC_MNC table"
    [Tags]    P1_PCRF_FRR_4683
    Set Test Variable    ${SHELL_PRE_CMD}    1
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_382
    [Documentation]    "To Verify PCRF application behaviour on receiving APN  that is is configured in THIRD PARTY APN Billing system for SDFT model and comming MCC-MNC matches with Home_MCC_MNC table but not with network-ID"
    [Tags]    P1_PCRF_FRR_4683
    Set Test Variable    ${SHELL_PRE_CMD}    1
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_383
    [Documentation]    "To Verify PCRF application behaviour on receiving APN  that is is configured in THIRD PARTY APN Billing system for SDFT model and comming MCC-MNC not matches with Home_MCC table"
    [Tags]    P1_PCRF_FRR_4683
    Set Test Variable    ${SHELL_PRE_CMD}    1
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_384
    [Documentation]    "To Verify PCRF application behaviour on receiving APN  that is is configured in THIRD PARTY APN Billing system for SDFT model and comming MCC matches with Home_MCC table and RAT change in update request."
    [Tags]    P1_PCRF_FRR_4683
    Set Test Variable    ${SHELL_PRE_CMD}    1
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_385
    [Documentation]    "To Verify PCRF application behaviour on receiving APN  that is is configured in THIRD PARTY APN Billing system for SDFT model and comming MCC-MNC matches with Home_MCC_MNC table and RAT change in update request."
    [Tags]    P1_PCRF_FRR_4683
    Set Test Variable    ${SHELL_PRE_CMD}    1
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_386
    [Documentation]    "To Verify PCRF application behaviour on receiving APN  that is is configured in THIRD PARTY APN Billing system for SDFT model and comming MCC-MNC matches with Home_MCC_MNC table but not with network-ID and RAT change in update request"
    [Tags]    P1_PCRF_FRR_4683
    Set Test Variable    ${SHELL_PRE_CMD}    1
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_387
    [Documentation]    "To Verify PCRF application behaviour on receiving APN  that is is configured in THIRD PARTY APN Billing system for SDFT model and comming MCC-MNC not matches with Home_MCC table and RAT change in update request."
    [Tags]    P1_PCRF_FRR_4683
    Set Test Variable    ${SHELL_PRE_CMD}    1
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_388
    [Documentation]    "To Verify PCRF application behaviour on receiving APN  that is is configured in THIRD PARTY APN Billing system for SDFT model when entry in Generic SDFT table."
    [Tags]    P1_PCRF_FRR_4683
    Set Test Variable    ${SHELL_PRE_CMD}    1
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_389
    [Documentation]    "To Verify PCRF application behaviour on receiving APN  that is is configured in THIRD PARTY APN Billing system for SDFT model and RAT change in Update request when entry in Generic SDFT table."
    [Tags]    P1_PCRF_FRR_4683
    Set Test Variable    ${SHELL_PRE_CMD}    1
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_390
    [Documentation]    "To Verify PCRF application behaviour on receiving APN  that is is configured in THIRD PARTY APN Billing system for SDFT model when no entry in Generic SDFT or SUB_SDFT table."
    [Tags]    P1_PCRF_FRR_4683
    Set Test Variable    ${SHELL_PRE_CMD}    1
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}


*** Keywords ***
