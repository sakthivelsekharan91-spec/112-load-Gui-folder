*** Settings ***
Documentation     PCRF_FRR_4697
Suite Setup       SUITE STARTUP
Test Teardown     TEST STOP
Force Tags        PCRF_FRR_4697
Default Tags      P2
Test Timeout      5 minutes
Library           Collections
Library           SSHLibrary
Library           OperatingSystem
Library           String
Library           BuiltIn
Library           DateTime
Library           DatabaseLibrary
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_MGTS_CONNECT.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_START_STOP.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_APP_CONNECT.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_SEAGULL_RUN.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_DB_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_LOGGING.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_CDR_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_SUITE_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_PCAP_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_SHELL_MODULE.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_REMOTE_APP.robot
Resource          /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/MODULES/AUTO_TESTCASE_MODULE.robot
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_MAIN_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_LOGGING_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_CDR_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_DB_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_SEAGULL_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_PCAP_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_SHELL_COMMAND_DETAILS.py
Variables         /opt/product/AUTOMATION/TEST_AUTOMATION_FRAMEWORK/PCRF/CONFIG/AUTO_REMOTE_APP_DETAILS.py

*** Variables ***
${LOGGER_Validation}    1
${CDR_Validation}    1
${PRE_DB_Validation}    1
${POST_DB_QUERY_Validation}    1
${SHELL_ON_CALL_CMD}    1

*** Test Cases ***
PCRF_AUTO_391
    [Documentation]    "To verify whether PCRF application is installing the rules based on the PCI and status of the subscriber received from the RRBS application."
    [Tags]    P1_PCRF_FRR_4697
    Set Test Variable    ${SHELL_PRE_CMD}    1
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_392
    [Documentation]    "To verify whether PCRF application is sending the SNR request to RRBS application when the configured APN is received in CCR-U request and subscriber moving from first region to second region."
    [Tags]    P1_PCRF_FRR_4697
    Set Test Variable    ${SHELL_PRE_CMD}    1
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_393
    [Documentation]    "To verify whether PCRF application is sending the SLR request to RRBS application when the configured APN is received in CCR-I request(2nd Region)."
    [Tags]    P1_PCRF_FRR_4697
    Set Test Variable    ${SHELL_PRE_CMD}    1
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_394
    [Documentation]    "To verify whether PCRF application is sending the SNR request to RRBS application when the configured APN is received in CCR-U request and subscriber moving from second region to Third Region."
    [Tags]    P1_PCRF_FRR_4697
    Set Test Variable    ${SHELL_PRE_CMD}    1
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_395
    [Documentation]    "To verify whether PCRF application is sending the SLR request to RRBS application when the configured APN is received in CCR-I request(3rd Region)."
    [Tags]    P1_PCRF_FRR_4697
    Set Test Variable    ${SHELL_PRE_CMD}    1
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_396
    [Documentation]    "To verify whether PCRF application is sending the SNR request to RRBS application when the configured APN is received in CCR-U request and subscriber moving from Third Region to Fourth Region."
    [Tags]    P1_PCRF_FRR_4697
    Set Test Variable    ${SHELL_PRE_CMD}    1
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_397
    [Documentation]    "To verify whether PCRF application is sending the SLR request to RRBS application when the configured APN is received in CCR-I request(4th Region)."
    [Tags]    P1_PCRF_FRR_4697
    Set Test Variable    ${SHELL_PRE_CMD}    1
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_398
    [Documentation]    "To verify whether PCRF application is sending the SNR request to RRBS application when the configured APN is received in CCR-U request and subscriber moving from Third Region to Fourth Region."
    [Tags]    P1_PCRF_FRR_4697
    Set Test Variable    ${SHELL_PRE_CMD}    1
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_399
    [Documentation]    "To verify whether PCRF application is sending the SLR request to RRBS application when the configured APN is received in CCR-I request(last Region reached)."
    [Tags]    P1_PCRF_FRR_4697
    Set Test Variable    ${SHELL_PRE_CMD}    1
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_400
    [Documentation]    "To verify whether PCRF application is sending the SLR request to RRBS application after last violation configured days are completed (T4 days completed) bundle."
    [Tags]    P1_PCRF_FRR_4697
    Set Test Variable    ${SHELL_PRE_CMD}    1
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_401
    [Documentation]    "To verify whether PCRF application is installing the rules based on the PCI and status of the subscriber received from the RRBS application.-ROAM CALL"
    [Tags]    P1_PCRF_FRR_4697
    Set Test Variable    ${SHELL_PRE_CMD}    1
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_402
    [Documentation]    "To verify whether PCRF application is sending the SNR request to RRBS application when the configured APN is received in CCR-U request and subscriber moving from first region to second region-ROAM CALL."
    [Tags]    P1_PCRF_FRR_4697
    Set Test Variable    ${SHELL_PRE_CMD}    1
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_403
    [Documentation]    "To verify whether PCRF application is sending the SLR request to RRBS application when the configured APN is received in CCR-I request(2nd Region)-ROAM REGION."
    [Tags]    P1_PCRF_FRR_4697
    Set Test Variable    ${SHELL_PRE_CMD}    1
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_404
    [Documentation]    "To verify whether PCRF application is sending the SNR request to RRBS application when the configured APN is received in CCR-U request and subscriber moving from second region to Third Region.-ROAM REGION"
    [Tags]    P1_PCRF_FRR_4697
    Set Test Variable    ${SHELL_PRE_CMD}    1
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_405
    [Documentation]    "To verify whether PCRF application is sending the SLR request to RRBS application when the configured APN is received in CCR-I request(3rd Region)-ROAM call."
    [Tags]    P1_PCRF_FRR_4697
    Set Test Variable    ${SHELL_PRE_CMD}    1
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_406
    [Documentation]    "To verify whether PCRF application is sending the SLR request to RRBS application when the configured APN is received in CCR-I request(3rd Region)-ROAM call."
    [Tags]    P1_PCRF_FRR_4697
    Set Test Variable    ${SHELL_PRE_CMD}    1
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_407
    [Documentation]    "To verify whether PCRF application is sending the SLR request to RRBS application when the configured APN is received in CCR-I request(4th Region)-ROAM CALL."
    [Tags]    P1_PCRF_FRR_4697
    Set Test Variable    ${SHELL_PRE_CMD}    1
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_408
    [Documentation]    "To verify whether PCRF application is sending the SNR request to RRBS application when the configured APN is received in CCR-U request and subscriber moving from Third Region to Fourth Region.-ROAM CALL"
    [Tags]    P1_PCRF_FRR_4697
    Set Test Variable    ${SHELL_PRE_CMD}    1
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_409
    [Documentation]    "To verify whether PCRF application is sending the SLR request to RRBS application when the configured APN is received in CCR-I request(last Region reached)."
    [Tags]    P1_PCRF_FRR_4697
    Set Test Variable    ${SHELL_PRE_CMD}    1
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_410
    [Documentation]    "To verify whether PCRF application is sending the SLR request to RRBS application after last violation configured days are completed (T4 days completed) bundle."
    [Tags]    P1_PCRF_FRR_4697
    Set Test Variable    ${SHELL_PRE_CMD}    1
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_411
    [Documentation]    "To verify whether PCRF application is sending the SNR request to RRBS application when the configured APN is received in CCR-U request and subscriber moving from first region of first bundle to second bundle first region Home CALL."
    [Tags]    P1_PCRF_FRR_4697
    Set Test Variable    ${SHELL_PRE_CMD}    1
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_412
    [Documentation]    "To verify whether PCRF application is sending the SLR request to RRBS application when the configured APN is received in CCR-I request(2nb bundle first Region)."
    [Tags]    P1_PCRF_FRR_4697
    Set Test Variable    ${SHELL_PRE_CMD}    1
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

PCRF_AUTO_413
    [Documentation]    "To verify whether PCRF application is sending the SNR request to RRBS application when the configured APN is received in CCR-U request and subscriber moving from second bundle first region first bundle second Region.-ROAM REGION"
    [Tags]    P1_PCRF_FRR_4697
    Set Test Variable    ${SHELL_PRE_CMD}    1
    ${TC_RESULT} =    START AUTO
    log    ${TC_RESULT}

*** Keywords ***
