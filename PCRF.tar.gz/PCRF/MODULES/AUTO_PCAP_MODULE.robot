*** Settings ***
Library           Collections
Library           SSHLibrary
Library           OperatingSystem
Library           String
Library           BuiltIn
Library           DateTime
Library           Collections

*** Variables ***

*** Keyword ***
START PCAP
    [Documentation]    This Keyword initiates the PCAP Capturing for all servers listed in Configuration File
    Set Test Variable    @{PCAP_PID_LISTS}    @{EMPTY}
    ${NUM_OF_PCAP_SERVERS}=    Get Length    ${PCAP_SERVER_ALIAS}
    Append To File    ${framework_log_file}    PCAP Capturing Initiated\n
    FOR    ${i}    IN RANGE    ${NUM_OF_PCAP_SERVERS}
    ${pcap_alias}=    Get From List    ${PCAP_SERVER_ALIAS}    ${i}
    ${pcap_platform}=    Set Variable    ${alias_platform_map}[${pcap_alias}]
    ${pcap_pattern}=    Get From List    ${PCAP_STRING}    ${i}
    ${remote_path}=    Get From List    ${PCAP_CAPTURE_REMOTE_PATH}    ${i}
    Switch Connection    ${pcap_alias}
    ${rc}=    BuiltIn.Run Keyword If    "${pcap_platform}"=="SOLARIS"    SSHLibrary.Start Command    ${pcap_pattern} -w ${remote_path}${TEST_NAME}_${pcap_alias}.pcap >/dev/null &
    ...    ELSE    SSHLibrary.Start Command    ${pcap_pattern} -w ${remote_path}${TEST_NAME}_${pcap_alias}.pcap >/dev/null
    END

STOP PCAP
    [Documentation]    This Keyword terminates the PCAP Capturing for all servers listed in Configuration File and also copy PCAP files to Local Path
    ${NUM_OF_PCAP_SERVERS}=    Get Length    ${PCAP_SERVER_ALIAS}
    FOR    ${i}    IN RANGE    ${NUM_OF_PCAP_SERVERS}
    ${pcap_alias}=    Get From List    ${PCAP_SERVER_ALIAS}    ${i}
    ${pcap_platform}=    Set Variable    ${alias_platform_map}[${pcap_alias}]
    ${remote_path}=    Get From List    ${PCAP_CAPTURE_REMOTE_PATH}    ${i}
    Switch Connection    ${pcap_alias}
    BuiltIn.Run Keyword If    "${pcap_platform}"=="SOLARIS"    SSHLibrary.Execute Command    /usr/ucb/ps -auxww | grep "${remote_path}${TEST_NAME}_${pcap_alias}.pcap" | grep -v grep | awk '{print $2}' | xargs kill -9
    ...    ELSE    SSHLibrary.Execute Command    ps -auxww | grep "${remote_path}${TEST_NAME}_${pcap_alias}.pcap" | grep -v grep | awk '{print $2}' | xargs kill -2
    SSHLibrary.Get File    ${remote_path}${TEST_NAME}_${pcap_alias}.pcap    ${result_path}
    END
    Append To File    ${framework_log_file}    PCAP Capturing Terminated\n

CAPTURE PCAP XML
    [Documentation]    This Keyword is used to convert PCAP file to XML file and validates XML file with reference file to return PCAP Success Status
    Set Test Variable    @{PCAP_SERVERS_STATUS}    @{EMPTY}
    ${NUM_OF_PCAP_SERVERS}=    Get Length    ${PCAP_SERVER_ALIAS}
    Append To File    ${framework_log_file}    Decoding PCAP Trace into XML File\n
    @{test_files}=    OperatingSystem.List Files In Directory    ${PRE_POST_VALIDATE_PATH}[${INPUT_HIERARCHY}]${suite_name}/    ${TEST_NAME}.txt
    ${test_file_length}=    Get Length    ${test_files}
    FOR    ${i}    IN RANGE    ${NUM_OF_PCAP_SERVERS}
    ${validate_file}=    Get From List    ${PCAP_VALIDATION_INPUT_ALIAS}    ${i}
    ${grep_string}=    BuiltIn.Run Keyword If    ${test_file_length}>${0}    Grep File    ${PRE_POST_VALIDATE_PATH}[${INPUT_HIERARCHY}]${suite_name}/${TEST_NAME}.txt    ${validate_file}_PCAP
    ...    encoding=UTF-8
    ${length}=    Get Length    ${grep_string}
    BuiltIn.Run Keyword If    ${length}>${0}    WRITE LATEST REF FILE    ${grep_string}\n
    ${pcap_alias}=    BuiltIn.Run Keyword If    ${length}>${0}    Get From List    ${PCAP_SERVER_ALIAS}    ${i}
    ${remote_path}=    BuiltIn.Run Keyword If    ${length}>${0}    Get From List    ${PCAP_CAPTURE_REMOTE_PATH}    ${i}
    ${PER_SERVER_XML_CONVERTER}=    BuiltIn.Run Keyword If    ${length}>${0}    Get From List    ${PCAP_XML_CONVERSION_STRING}    ${i}
    ${PER_SERVER_XML_END_CONVERTER}=    BuiltIn.Run Keyword If    ${length}>${0}    Get From List    ${PCAP_XML_CONVERSION_END_STRING}    ${i}
    BuiltIn.Run Keyword If    ${length}>${0}    XML CONVERTER    ${pcap_alias}    ${remote_path}    ${PER_SERVER_XML_CONVERTER}
    ...    ${PER_SERVER_XML_END_CONVERTER}
    ${status}=    BuiltIn.Run Keyword If    ${length}>${0}    XML COMPARE    ${pcap_alias}
    Append To List    ${PCAP_SERVERS_STATUS}    ${status}
    END
    ${pcap_server_flag}=    Count Values In List    ${PCAP_SERVERS_STATUS}    ${0}
    ${no_of_items}=    Get Length    ${PCAP_SERVERS_STATUS}
    ${pcap_server_flag}=    Run Keyword If    ${pcap_server_flag}>${0}    Set Variable    ${FAIL}
    ...    ELSE IF    ${no_of_items}>${0}    Set Variable    PASS
    ...    ELSE    Set Variable    NONE
    Append To File    ${framework_log_file}    XML Decoding Done\n
    [Return]    ${pcap_server_flag}

XML CONVERTER
    [Arguments]    ${pcap_alias}    ${remote_path}    ${XML_CONVERSION_STRING}    ${XML_CONVERSION_END_STRING}
    [Documentation]    This Keyword is used to convert PCAP file to XML file and also copy the coverted XML file into Local Path
    Switch Connection    ${pcap_alias}
    SSHLibrary.Execute Command    ${XML_CONVERSION_STRING} -r ${remote_path}${TEST_NAME}_${pcap_alias}.pcap ${XML_CONVERSION_END_STRING} > ${remote_path}/${TEST_NAME}_${pcap_alias}.xml
    SSHLibrary.Execute Command    chmod 666 ${remote_path}/${TEST_NAME}_${pcap_alias}.xml
    SSHLibrary.Get File    ${remote_path}${TEST_NAME}_${pcap_alias}.xml    ${result_path}

XML COMPARE
    [Arguments]    ${pcap_alias}
    [Documentation]    This Keyword is used to validate converted PCAP XML file for the test case with the reference file and return PASS/FAIL PCAP status
    Set Test Variable    @{PCAP_STATUS_LIST}    @{EMPTY}
    ${line_number}=    Get Line Count    ${grep_string}
    FOR    ${i}    IN RANGE    ${line_number}
    ${lines}=    Get Line    ${grep_string}    ${i}
    ${line}=    Fetch From Right    ${lines}    :${SPACE}
    ${generated_pcap_xml}=    BuiltIn.Run Keyword If    ${PCAP_GREP_TYPE}==${1}    Operating System.Grep File    ${result_path}/${TEST_NAME}_${pcap_alias}.xml    ${line}
    ...    ELSE    Operating System.Run    grep ${line} ${result_path}/${TEST_NAME}_${pcap_alias}.xml
    ${local_pcap_status}=    Get Length    ${generated_pcap_xml}
    BuiltIn.Run Keyword If    ${local_pcap_status}==${0}    BuiltIn.Run Keyword    PCAP_LOGGING    ${pcap_alias}    ${lines}
    Append To List    ${PCAP_STATUS_LIST}    ${local_pcap_status}
    END
    ${pcap_flag}=    Count Values In List    ${PCAP_STATUS_LIST}    ${0}
    ${pcap_flag}=    Run Keyword If    ${pcap_flag}>${0}    Set Variable    ${0}
    ...    ELSE    Set Variable    ${1}
    [Return]    ${pcap_flag}

PCAP_LOGGING
    [Arguments]    ${pcap_alias}    ${line}
    [Documentation]    This Keyword is used to log the PCAP XML Messages for which Test Case Fails
    ${file}=    Set Variable    ${result_path}/PCAP_FAILURE_${TEST_NAME}_${pcap_alias}.txt
    Append To File    ${file}    ${line}

EXECUTE PCAP
    [Documentation]    This consilated keyword calls STOP PCAP and CAPTURE PCAP XML Keywords
    STOP PCAP
    ${status}=    BuiltIn.Run Keyword If    ${XML_DECODE_Validation}==${1}    BuiltIn.Run Keyword    CAPTURE PCAP XML
    [Return]    ${status}
