*** Settings ***
Library           Collections
Library           SSHLibrary
Library           OperatingSystem
Library           String
Library           BuiltIn
Library           DateTime
Library           Collections



*** Variables ***



*** Keyword ***
START REMOTE APP
    [Arguments]    ${alias}
    ${app_product}=    Get From Dictionary    ${alias_script_map}    ${alias}
    ${framework_log_file}=    Set Variable    ${AUTOMATION_TEMP_PATH}/FRAMEWORK_LOG.txt
        :FOR    ${i}    IN    @{app_product}
    \    START APP    ${i}
    Sleep    ${SLEEP_TIME}S


IS APPLICATION ALIVE
    ${binaries}=    Get Dictionary Keys    ${PRODUCT_SERVER_DICTIONARY}
        :FOR    ${i}    IN    @{binaries}
    \    CHECK REMOTE APP    ${i}


KILL ALL APPLICATION
    ${binaries}=    Get Dictionary Keys    ${PRODUCT_SERVER_DICTIONARY}
    ${framework_log_file}=    Set Variable    ${AUTOMATION_TEMP_PATH}/FRAMEWORK_LOG.txt
        :FOR    ${i}    IN    @{binaries}
    \    KILL REMOTE APP    ${i}
    Remove File    ${AUTOMATION_TEMP_PATH}/FRAMEWORK_LOG.txt


CHECK REMOTE APP
    [Arguments]    ${product}
    ${alias}=    Get From Dictionary    ${PRODUCT_SERVER_DICTIONARY}    ${product}
    Switch Connection    ${alias}
    ${cmd}=    Set Variable    ps -ef | grep ${product} | grep -v grep | awk '{print $2}'
    ${pid}=    SSHLibrary.Execute Command    ${cmd}
    ${pid_length}=    Get Length    ${pid}
    ${app_script}=    Run Keyword If    ${pid_length}==${0}    Get From Dictionary    ${PRODUCT_SCRIPT_DICTIONARY}    ${product}
    ${path}    ${sh_file}=    Run Keyword If    ${pid_length}==${0}       Split String From Right    ${app_script}    :    1
    Run Keyword If    ${pid_length}==${0}       SSHLibrary.Start Command    cd ${path};${sh_file}
    Run Keyword If    ${pid_length}==${0}    Sleep    ${SLEEP_TIME}S

START APP
    [Arguments]    ${product}
    ${alias}=    Get From Dictionary    ${PRODUCT_SERVER_DICTIONARY}    ${product}
    Switch Connection    ${alias}
    Append To File    ${framework_log_file}    connected to server ${alias} and starting ${product}\n
    ${app_script}=    Get From Dictionary    ${PRODUCT_SCRIPT_DICTIONARY}    ${product}
    ${path}    ${sh_file}=    Split String From Right    ${app_script}    :    1
    SSHLibrary.Start Command    cd ${path};${sh_file}
    Sleep    ${1}S

REMOTE COMMAND EXECUTE
    [Arguments]    ${alias}    ${cmd}
    Switch Connection    ${alias}
    SSHLibrary.Execute Command    ${cmd}

KILL REMOTE APP
    [Arguments]    ${product}
    ${alias}=    Get From Dictionary    ${PRODUCT_SERVER_DICTIONARY}    ${product}
    Switch Connection    ${alias}
    Append To File    ${framework_log_file}    connected to server ${alias} and killing ${product}\n
    ${cmd}=    Set Variable    ps -ef | grep -w ${product} | grep -v grep | awk '{print $2}' | xargs kill -9
    SSHLibrary.Execute Command    ${cmd}
    Sleep    ${SLEEP_TIME}S

KILL REMOTE APPS
    [Arguments]    ${product}
    @{products}=    Split String    ${product}    ${SPACE}
        :FOR    ${i}    IN    @{products}
    \    ${alias}=    Get From Dictionary    ${PRODUCT_SERVER_DICTIONARY}    ${i}
    \    Switch Connection    ${alias}
    \    Append To File    ${framework_log_file}    connected to server ${alias} and killing ${i}\n
    \    ${cmd}=    Set Variable    ps -ef | grep -w ${i} | grep -v grep | awk '{print $2}' | xargs kill -9
    \    SSHLibrary.Execute Command    ${cmd}
    Sleep    ${SLEEP_TIME}S

GRACE EXIT REMOTE APP
    [Arguments]    ${product}    ${sleeptime}
    ${alias}=    Get From Dictionary    ${PRODUCT_SERVER_DICTIONARY}    ${product}
    ${kill_signal}=    Get From Dictionary    ${GRACE_EXIT_DICTIONARY}    ${product}
    Switch Connection    ${alias}
    Append To File    ${framework_log_file}    connected to server ${alias} and killing gracefully ${product}\n
    ${cmd}=    Set Variable    ps -ef | grep -w ${product} | grep -v grep | awk '{print $2}' | xargs ${kill_signal}
    SSHLibrary.Execute Command    ${cmd}
    Sleep    ${sleeptime}S

RESTART REMOTE APP
    [Arguments]    ${product}    ${setsleeptime}=40
    KILL REMOTE APP    ${product}
    Sleep    40S

RESTART REMOTE APP GRACEFULLY
    [Arguments]    ${product}    ${sleeptime}
    GRACE EXIT REMOTE APP    ${product}    ${sleeptime}
    START APP    ${product}

PREPARE EXPORT DATE VARIABLE
    [Timeout]    2 minute
    [Arguments]    ${product}    ${value}    ${inputtime}    ${Timezone}

    Set Test Variable    ${GetTimeZone}     date +"%Z %z"
    Set Test Variable    ${S_STARTTIME}     00:00:00
    Set Test Variable    ${S_ENDTIME}     24:00:00
    Set Test Variable    ${RemoteExportCmd}     TZ=${Timezone}
    Set Test Variable    ${SetExportCmd}      ${RemoteExportCmd}

    ${alias}=    Get From Dictionary    ${PRODUCT_SERVER_DICTIONARY}    ${product}
    Switch Connection    ${alias}

    ${getremotezone}=    SSHLibrary.Execute Command   ${GetTimeZone}
    ${splitremotezone}=    Split String    ${getremotezone}    ${SPACE}
    ${getremotetimezone}=    Set Variable    @{splitremotezone}[0]
    ${getremotetimevalue}=    Set Variable    @{splitremotezone}[1]

    ${timehr}=    Get Substring    ${getremotetimevalue}    1    3
    ${timemin}=   Get Substring    ${getremotetimevalue}    3    5
    ${getzone}=    Catenate    SEPARATOR=:    ${timehr}    ${timemin}
    ${getzonems}=    Catenate    SEPARATOR=:    ${getzone}    00

    ${getremoteisttime}=    SSHLibrary.Execute Command    TZ=${Timezone} date |awk -F" " '{print $4}'

    ${difftime}=    Subtract Time From Time    ${getremoteisttime}    ${inputtime}
    ${difftimehour}=    Convert Time    ${difftime}    timer    exclude_milles=yes
    ${intdifftime}=    Convert To String    ${difftime}
    ${getfirstvalue}=    Get Substring    ${intdifftime}    0    1

    ${extracttime}=    Run Keyword If    ${value}==0 and "${getfirstvalue}"=="-"    Get Substring    ${difftimehour}    1    -1
    ...    ELSE    Get Substring    ${difftimehour}    0    -1

    ${gettimediff}=    Run Keyword If    ${value}==-1    Subtract Time From Time    ${getremoteisttime}    ${S_STARTTIME}
    ...    ELSE IF    ${value}==1    Subtract Time From Time    ${S_ENDTIME}    ${getremoteisttime}
    ${gettimediffms}=    Run Keyword If    ${value}==-1 or ${value}==1    Convert Time    ${gettimediff}    timer    exclude_milles=yes

    ${getdaytime}=    Run Keyword If    ${value}==1    Add Time To Time    ${S_STARTTIME}    ${inputtime}
    ...    ELSE IF    ${value}==-1    Subtract Time From Time    ${S_ENDTIME}    ${inputtime}
    ${getdaytimems}=    Run Keyword If    ${value}==1 or ${value}==-1    Convert Time    ${getdaytime}    timer    exclude_milles=yes

    ${setdaytime}=    Run Keyword If    ${value}==-1 or ${value}==1    Add Time To Time    ${gettimediffms}    ${getdaytimems}
    ${setdaytimems}=    Run Keyword If    ${value}==1 or ${value}==-1     Convert Time    ${setdaytime}    timer    exclude_milles=yes

    ${setexportcmd}=    Run Keyword If    ${value}==1    Catenate    SEPARATOR=-    ${RemoteExportCmd}    ${setdaytimems};export TZ
    ...    ELSE IF    ${value}==-1    Catenate    SEPARATOR=+    ${RemoteExportCmd}    ${setdaytimems};export TZ
    ...    ELSE IF    ${value}==0 and "${getfirstvalue}"=="-"    Catenate    SEPARATOR=-    ${RemoteExportCmd}    ${extracttime};export TZ
    ...    ELSE IF    ${value}==0 and "${getfirstvalue}"!="-"    Catenate    SEPARATOR=+    ${RemoteExportCmd}    ${extracttime};export TZ
    ...    ELSE IF    ${value}==2    Catenate    SEPARATOR=-    ${RemoteExportCmd}    ${getzonems};export TZ

    [Return]    ${setexportcmd}