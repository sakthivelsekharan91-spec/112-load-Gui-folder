*** Settings ***
Library           Collections
Library           SSHLibrary    5min
Library           OperatingSystem
Library           String
Library           BuiltIn
Library           Process

*** Variables ***

*** Keyword ***
START AUTO
    [Documentation]    This Keyword Extracts Test Data from Test Setup File and calls RUN TEST SCENARIO Keyword.
    [Timeout]    4 minute 50 seconds
    ${SEAGULL_STATE_MACHINE}=    BuiltIn.Run Keyword If    ${MODEL_TYPE}==${1}    BuiltIn.Run Keyword If    ${SEAGULL_EXECUTION}==${1}    SEAGULL SCENARIO PREPARE
    ${SCEN_STATUS}    ${autostop_status}    ${cdr_status}    ${postdb_status}    ${pcap_status}    ${shellpre_status}    ${shelloncall_status}    ${shellpost_status}    ${http_status}    ${TC_RESULT}=    BuiltIn.Run Keyword If    ${MODEL_TYPE}==${0}
    ...    RUN TEST SCENARIO OLD    ${TC_CONF}    ${TC_SCEN}    ${TIMESTAMP}
    ...    ELSE    RUN TEST SCENARIO    ${SEAGULL_STATE_MACHINE}    ${SEAGULL_STATE_MACHINE}    ${TIMESTAMP}   
    log    TEST_RESULT=${TC_RESULT}
    log    Autostop_Status=${autostop_status}
    log    SCEN_STATUS=${SCEN_STATUS}
    log    POSTDB_STATUS=${postdb_status}
    log    CDR_STATUS=${cdr_status}
    log    PCAP_STATUS=${pcap_status}
    log    SOAP_STATUS=${http_status}
    Set Test Variable    ${TESTCASE_SCEN_STATUS}    ${SCEN_STATUS}
    Set Test Variable    ${TESTCASE_POSTDB_STATUS}    ${postdb_status}
    Set Test Variable    ${TESTCASE_CDR_STATUS}    ${cdr_status}
    Set Test Variable    ${TESTCASE_PCAP_STATUS}    ${pcap_status}
    Set Test Variable    ${TESTCASE_RESULT}    ${TC_RESULT}
    Set Test Variable    ${TESTCASE_SHELLPRE_STATUS}    ${shellpre_status}
    Set Test Variable    ${TESTCASE_SHELLON_STATUS}    ${shelloncall_status}
    Set Test Variable    ${TESTCASE_SHELLPOST_STATUS}    ${shellpost_status}
    Set Test Variable    ${TESTCASE_HTTP_STATUS}    ${http_status}
    Run Keyword if    '${TC_RESULT}'!='PASS'    BuiltIn.Run Keyword If    ${MODEL_TYPE}==${0}    BuiltIn.Run Keyword And Continue On Failure    Execute Automation DIRCOPY    ${TEST_NAME}    ${TIMESTAMP}
    Run Keyword if    '${TC_RESULT}'!='PASS'    Builtin.Fail    TC_FAIL
    [Return]    ${TC_RESULT}


START AUTO MSISDN
    [Documentation]    This Keyword Extracts Test Data from Test Setup File and calls RUN TEST SCENARIO Keyword.
    [Timeout]    4 minute 50 seconds
    ${SEAGULL_STATE_MACHINE}=    BuiltIn.Run Keyword If    ${MODEL_TYPE}==${1}    BuiltIn.Run Keyword If    ${SEAGULL_EXECUTION}==${1}    SEAGULL SCENARIO PREPARE
    ${SCEN_STATUS}    ${autostop_status}    ${cdr_status}    ${postdb_status}    ${pcap_status}    ${shellpre_status}    ${shelloncall_status}    ${shellpost_status}    ${http_status}    ${TC_RESULT}=    BuiltIn.Run Keyword If    ${MODEL_TYPE}==${0}
    ...    RUN TEST SCENARIO OLD    ${TC_CONF}    ${TC_SCEN}    ${TIMESTAMP}
    ...    ELSE    RUN TEST SCENARIO MSISDN    ${SEAGULL_STATE_MACHINE}    ${SEAGULL_STATE_MACHINE}    ${TIMESTAMP}
    log    TEST_RESULT=${TC_RESULT}
    log    Autostop_Status=${autostop_status}
    log    SCEN_STATUS=${SCEN_STATUS}
    log    POSTDB_STATUS=${postdb_status}
    log    CDR_STATUS=${cdr_status}
    log    PCAP_STATUS=${pcap_status}
    log    SOAP_STATUS=${http_status}
    Set Test Variable    ${TESTCASE_SCEN_STATUS}    ${SCEN_STATUS}
    Set Test Variable    ${TESTCASE_POSTDB_STATUS}    ${postdb_status}
    Set Test Variable    ${TESTCASE_CDR_STATUS}    ${cdr_status}
    Set Test Variable    ${TESTCASE_PCAP_STATUS}    ${pcap_status}
    Set Test Variable    ${TESTCASE_RESULT}    ${TC_RESULT}
    Set Test Variable    ${TESTCASE_SHELLPRE_STATUS}    ${shellpre_status}
    Set Test Variable    ${TESTCASE_SHELLON_STATUS}    ${shelloncall_status}
    Set Test Variable    ${TESTCASE_SHELLPOST_STATUS}    ${shellpost_status}
    Set Test Variable    ${TESTCASE_HTTP_STATUS}    ${http_status}
    Run Keyword if    '${TC_RESULT}'!='PASS'    BuiltIn.Run Keyword If    ${MODEL_TYPE}==${0}    BuiltIn.Run Keyword And Continue On Failure    Execute Automation DIRCOPY    ${TEST_NAME}    ${TIMESTAMP}
    Run Keyword if    '${TC_RESULT}'!='PASS'    Builtin.Fail    TC_FAIL
    [Return]    ${TC_RESULT}


RUN TEST SCENARIO
    [Arguments]    ${CONFIG_FILE}    ${SCENARIO_FILE}    ${TIMESTAMP}
    [Documentation]    This Keyword Calls all Test Steps.
    [Timeout]    4 minute 01 seconds
    TEST START
    BuiltIn.Run Keyword If    ${test_file_length}!=${0}    BuiltIn.Run Keyword If    ${DB_Validation}==${1}    BuiltIn.Run Keyword If    ${PRE_DB_Validation}==${1}    BuiltIn.Run Keyword And Continue On Failure    PRECONDITION
    ${shellpre_status}=    BuiltIn.Run Keyword If    ${test_file_length}!=${0}    BuiltIn.Run Keyword If    ${SHELL_COMMAND_VALIDATION}==${1}    BuiltIn.Run Keyword If    ${SHELL_PRE_CMD}==${1}    BuiltIn.Run Keyword And Continue On Failure    SHELL PRECONDITION
    BuiltIn.Run Keyword And Continue On Failure    PREPROCESSING
    ${SCEN_STATUS}=    BuiltIn.Run Keyword If    ${SCENARIO_EXECUTION}==${1}    BuiltIn.Run Keyword And Continue On Failure    RUN SEAGULL SCENARIO    ${TEST_NAME}    ${CONFIG_FILE}    ${SCENARIO_FILE}
    BuiltIn.Run Keyword If    ${test_file_length}!=${0}    BuiltIn.Run Keyword If    ${DB_Validation}==${1}    BuiltIn.Run Keyword If    ${ON_CALL_DB_Validation}==${1}    BuiltIn.Run Keyword And Continue On Failure    ONCALLDBCONDITION
    ${shelloncall_status}=    BuiltIn.Run Keyword If    ${test_file_length}!=${0}    BuiltIn.Run Keyword If    ${SHELL_COMMAND_VALIDATION}==${1}    BuiltIn.Run Keyword If    ${SHELL_ON_CALL_CMD}==${1}    BuiltIn.Run Keyword And Continue On Failure    SHELL ON CALL CONDITION
    Sleep    ${POST_SLEEP_EXECUTION}s    Wait for a POST QUERY Execution
    BuiltIn.Run Keyword If    ${SCENARIO_EXECUTION}==${1}    BuiltIn.Run Keyword And Continue On Failure    VERIFY SEAGULL SCENARIO STATUS    ${TEST_NAME}
    ${http_status}=    BuiltIn.Run Keyword If    ${SOAP_Validation}==${1}    BuiltIn.Run Keyword And Continue On Failure    HTTP
    ${xml_status}=    BuiltIn.Run Keyword If    ${XML_Validation}==${1}    BuiltIn.Run Keyword And Continue On Failure    XML
    log    ${xml_status}
    ${autostop_status}=    BuiltIn.Run Keyword If    ${LOGGER_Validation}==${1}    BuiltIn.Run Keyword And Continue On Failure    LOGGER
    ${shellpost_status}=    BuiltIn.Run Keyword If    ${test_file_length}!=${0}    BuiltIn.Run Keyword If    ${SHELL_COMMAND_VALIDATION}==${1}    BuiltIn.Run Keyword If    ${SHELL_POST_CMD}==${1}    BuiltIn.Run Keyword And Continue On Failure    SHELL POST CONDITION
    ${pcap_status}=    BuiltIn.Run Keyword If    ${test_file_length}!=${0}    BuiltIn.Run Keyword If    ${PCAP_Validation}==${1}    BuiltIn.Run Keyword And Continue On Failure    EXECUTE PCAP
    ${cdr_status}=    BuiltIn.Run Keyword If    ${test_file_length}!=${0}    BuiltIn.Run Keyword If    ${CDR_Validation}==${1}    BuiltIn.Run Keyword And Continue On Failure    CDR
    ${postdb_status}=    BuiltIn.Run Keyword If    ${test_file_length}!=${0}    BuiltIn.Run Keyword If    ${DB_Validation}==${1}    BuiltIn.Run Keyword If    ${POST_DB_QUERY_Validation}==${1}    BuiltIn.Run Keyword And Continue On Failure    POSTCONDITION
    ${SCEN_RESULT}=    BuiltIn.Run Keyword If    ${SCENARIO_EXECUTION}==${1}    BuiltIn.Run Keyword And Continue On Failure    GET SEAGULL RESULT    ${TEST_NAME}
    ${TC_RESULT}=    BuiltIn.Run Keyword And Continue On Failure    Set Variable If    '${SCEN_RESULT}'in['True','NULL','None'] and '${cdr_status}'in['PASS','NONE','None'] and '${pcap_status}'in['PASS','NONE','None'] and '${autostop_status}'in['PASS','NONE','None'] and '${postdb_status}'in['PASS','NONE','None'] and '${http_status}' in['Pass','None','DONE']    PASS    FAIL
    BuiltIn.Run Keyword If    ${MIGRATION_FLAG}==${2}    BuiltIn.Run Keyword If    '${TC_RESULT}' in['PASS']    Copy File    ${LATEST_REF_PATH}${TEST_NAME}.txt    ${PRE_POST_VALIDATE_PATH}
    [Return]    ${SCEN_RESULT}    ${autostop_status}    ${cdr_status}    ${postdb_status}    ${pcap_status}    ${shellpre_status}    ${shelloncall_status}    ${shellpost_status}    ${http_status}    ${TC_RESULT}


RUN TEST SCENARIO OLD    [Arguments]    ${CONFIG_FILE}    ${SCENARIO_FILE}    ${TIMESTAMP}
    [Documentation]    This Keyword Calls all Test Steps.
    [Timeout]    4 minute 01 seconds
    ${predb_status}=     BuiltIn.Run Keyword And Continue On Failure    Execute DB Precondition    ${TEST_NAME}    ${TIMESTAMP}
    ${shellpre_status}=     BuiltIn.Run Keyword And Continue On Failure    Execute Automation SHELL_PRE    ${TEST_NAME}    ${TIMESTAMP}
    BuiltIn.Run Keyword And Continue On Failure    Execute Automation Start    ${TEST_NAME}    ${TIMESTAMP}
    ${SCEN_STATUS}=    BuiltIn.Run Keyword And Continue On Failure    RUN SEAGULL SCENARIO    ${TEST_NAME}    ${CONFIG_FILE}    ${SCENARIO_FILE}
    ${oncalldb_status}=    BuiltIn.Run Keyword And Continue On Failure    Execute DB Oncallcondition    ${TEST_NAME}    ${TIMESTAMP}
    ${shelloncall_status}=    BuiltIn.Run Keyword And Continue On Failure    Execute Automation ShellOncall    ${TEST_NAME}    ${TIMESTAMP}
    Sleep    ${TC_POSTTIME}s    Wait for a POST QUERY Execution
    BuiltIn.Run Keyword And Continue On Failure    VERIFY SEAGULL SCENARIO STATUS    ${TEST_NAME}
    ${autostop_status}=    BuiltIn.Run Keyword And Continue On Failure    Execute Automation Stop    ${TEST_NAME}    ${TIMESTAMP}
    ${shellpost_status}=     BuiltIn.Run Keyword And Continue On Failure    Execute Automation SHELL_POST    ${TEST_NAME}    ${TIMESTAMP}
    ${pcap_status}=     BuiltIn.Run Keyword And Continue On Failure    Execute Automation PCAP    ${TEST_NAME}    ${TIMESTAMP}
    ${cdr_status}=    BuiltIn.Run Keyword And Continue On Failure    Execute Automation CDR    ${TEST_NAME}    ${TIMESTAMP}
    ${postdb_status}=     BuiltIn.Run Keyword And Continue On Failure    Execute DB Postcondition    ${TEST_NAME}    ${TIMESTAMP}
    ${SCEN_RESULT}=    BuiltIn.Run Keyword And Continue On Failure    GET SEAGULL RESULT    ${TEST_NAME}
    ${http_status}=    Set Variable    ${None}
    ${TC_RESULT}=    BuiltIn.Run Keyword And Continue On Failure    Set Variable If	'${SCEN_RESULT}'in['True','NULL'] and '${cdr_status}'in['PASS','NULL'] and '${pcap_status}'in['PASS','NULL'] and '${autostop_status}'in['pass','null'] and '${postdb_status}'in['pass','null']    PASS    FAIL
    [Return]    ${SCEN_RESULT}    ${autostop_status}    ${cdr_status}    ${postdb_status}    ${pcap_status}    ${shellpre_status}    ${shelloncall_status}    ${shellpost_status}    ${http_status}    ${TC_RESULT}


RUN TEST SCENARIO MSISDN
    [Arguments]    ${CONFIG_FILE}    ${SCENARIO_FILE}    ${TIMESTAMP}
    [Documentation]    This Keyword Calls all Test Steps.
    [Timeout]    4 minute 01 seconds
    TEST START
    BuiltIn.Run Keyword If    ${test_file_length}!=${0}    BuiltIn.Run Keyword If    ${DB_Validation}==${1}    BuiltIn.Run Keyword If    ${PRE_DB_Validation}==${1}    BuiltIn.Run Keyword And Continue On Failure    PRECONDITION
    ${shellpre_status}=    BuiltIn.Run Keyword If    ${test_file_length}!=${0}    BuiltIn.Run Keyword If    ${SHELL_COMMAND_VALIDATION}==${1}    BuiltIn.Run Keyword If    ${SHELL_PRE_CMD}==${1}    BuiltIn.Run Keyword And Continue On Failure    SHELL PRECONDITION
    BuiltIn.Run Keyword And Continue On Failure    PREPROCESSING
    ${SCEN_STATUS}=    BuiltIn.Run Keyword If    ${SCENARIO_EXECUTION}==${1}    BuiltIn.Run Keyword And Continue On Failure    RUN SEAGULL SCENARIO    ${TEST_NAME}    ${CONFIG_FILE}    ${SCENARIO_FILE}
    BuiltIn.Run Keyword If    ${test_file_length}!=${0}    BuiltIn.Run Keyword If    ${DB_Validation}==${1}    BuiltIn.Run Keyword If    ${ON_CALL_DB_Validation}==${1}    BuiltIn.Run Keyword And Continue On Failure    ONCALLDBCONDITION
    ${shelloncall_status}=    BuiltIn.Run Keyword If    ${test_file_length}!=${0}    BuiltIn.Run Keyword If    ${SHELL_COMMAND_VALIDATION}==${1}    BuiltIn.Run Keyword If    ${SHELL_ON_CALL_CMD}==${1}    BuiltIn.Run Keyword And Continue On Failure    SHELL ON CALL CONDITION
    Sleep    ${POST_SLEEP_EXECUTION}s    Wait for a POST QUERY Execution
    BuiltIn.Run Keyword If    ${SCENARIO_EXECUTION}==${1}    BuiltIn.Run Keyword And Continue On Failure    VERIFY SEAGULL SCENARIO STATUS    ${TEST_NAME}
    ${http_status}=    BuiltIn.Run Keyword If    ${SOAP_Validation}==${1}    BuiltIn.Run Keyword And Continue On Failure    HTTP
    ${autostop_status}=    BuiltIn.Run Keyword If    ${LOGGER_Validation}==${1}    BuiltIn.Run Keyword And Continue On Failure    LOGGER
    ${shellpost_status}=    BuiltIn.Run Keyword If    ${test_file_length}!=${0}    BuiltIn.Run Keyword If    ${SHELL_COMMAND_VALIDATION}==${1}    BuiltIn.Run Keyword If    ${SHELL_POST_CMD}==${1}    BuiltIn.Run Keyword And Continue On Failure    SHELL POST CONDITION
    ${pcap_status}=    BuiltIn.Run Keyword If    ${test_file_length}!=${0}    BuiltIn.Run Keyword If    ${PCAP_Validation}==${1}    BuiltIn.Run Keyword And Continue On Failure    EXECUTE PCAP
    ${cdr_status}=    BuiltIn.Run Keyword If    ${test_file_length}!=${0}    BuiltIn.Run Keyword If    ${CDR_Validation}==${1}    BuiltIn.Run Keyword And Continue On Failure    CDR
    ${postdb_status}=    BuiltIn.Run Keyword If    ${test_file_length}!=${0}    BuiltIn.Run Keyword If    ${DB_Validation}==${1}    BuiltIn.Run Keyword If    ${POST_DB_QUERY_Validation}==${1}    BuiltIn.Run Keyword And Continue On Failure    POSTCONDITION WITH MSISDN
    ${SCEN_RESULT}=    BuiltIn.Run Keyword If    ${SCENARIO_EXECUTION}==${1}    BuiltIn.Run Keyword And Continue On Failure    GET SEAGULL RESULT    ${TEST_NAME}
    ${TC_RESULT}=    BuiltIn.Run Keyword And Continue On Failure    Set Variable If    '${SCEN_RESULT}'in['True','NULL','None'] and '${cdr_status}'in['PASS','NONE','None'] and '${pcap_status}'in['PASS','NONE','None'] and '${autostop_status}'in['PASS','NONE','None'] and '${postdb_status}'in['PASS','NONE','None'] and '${http_status}' in['Pass','None','DONE']    PASS    FAIL
    BuiltIn.Run Keyword If    ${MIGRATION_FLAG}==${2}    BuiltIn.Run Keyword If    '${TC_RESULT}' in['PASS']    Copy File    ${LATEST_REF_PATH}${TEST_NAME}.txt    ${PRE_POST_VALIDATE_PATH}
    [Return]    ${SCEN_RESULT}    ${autostop_status}    ${cdr_status}    ${postdb_status}    ${pcap_status}    ${shellpre_status}    ${shelloncall_status}    ${shellpost_status}    ${http_status}    ${TC_RESULT}


START MGTS AUTO    [Arguments]    ${SCENARIO_NAME}
    [Documentation]    This Keyword Extracts Test Data from Test Setup File and calls RUN TEST SCENARIO Keyword.
    [Timeout]    10 minute 50 seconds
    Set Test Variable    ${TC_ID}    ${SCENARIO_NAME}
    ${SCEN_STATUS}    ${autostop_status}    ${cdr_status}    ${postdb_status}    ${pcap_status}    ${shellpre_status}    ${shelloncall_status}    ${shellpost_status}    ${TC_RESULT}=    BuiltIn.Run Keyword If    ${MODEL_TYPE}==${0}
    ...    RUN TEST SCENARIO OLD    ${TC_CONF}    ${TC_SCEN}    ${TIMESTAMP}
    ...    ELSE    RUN MGTS TEST SCENARIO    ${TIMESTAMP}   
    log    TEST_RESULT=${TC_RESULT}
    log    Autostop_Status=${autostop_status}
    log    SCEN_STATUS=${SCEN_STATUS}
    log    POSTDB_STATUS=${postdb_status}
    log    CDR_STATUS=${cdr_status}
    log    PCAP_STATUS=${pcap_status}
    Set Test Variable    ${TESTCASE_SCEN_STATUS}    ${SCEN_STATUS}
    Set Test Variable    ${TESTCASE_POSTDB_STATUS}    ${postdb_status}
    Set Test Variable    ${TESTCASE_CDR_STATUS}    ${cdr_status}
    Set Test Variable    ${TESTCASE_PCAP_STATUS}    ${pcap_status}
    Set Test Variable    ${TESTCASE_RESULT}    ${TC_RESULT}
    Set Test Variable    ${TESTCASE_SHELLPRE_STATUS}    ${shellpre_status}
    Set Test Variable    ${TESTCASE_SHELLON_STATUS}    ${shelloncall_status}
    Set Test Variable    ${TESTCASE_SHELLPOST_STATUS}    ${shellpost_status}
    Run Keyword if    '${TC_RESULT}'!='PASS'    BuiltIn.Run Keyword If    ${MODEL_TYPE}==${0}    BuiltIn.Run Keyword And Continue On Failure    Execute Automation DIRCOPY    ${TEST_NAME}    ${TIMESTAMP}
    Run Keyword if    '${TC_RESULT}'!='PASS'    Builtin.Fail    TC_FAIL
    [Return]    ${TC_RESULT}

RUN MGTS TEST SCENARIO
    [Arguments]    ${TIMESTAMP}
    [Documentation]    This Keyword Calls all Test Steps.
    [Timeout]    10 minute 01 seconds
    TEST START
    BuiltIn.Run Keyword If    ${test_file_length}!=${0}    BuiltIn.Run Keyword If    ${DB_Validation}==${1}    BuiltIn.Run Keyword If    ${PRE_DB_Validation}==${1}    BuiltIn.Run Keyword And Continue On Failure    PRECONDITION
    ${shellpre_status}=    BuiltIn.Run Keyword If    ${test_file_length}!=${0}    BuiltIn.Run Keyword If    ${SHELL_COMMAND_VALIDATION}==${1}    BuiltIn.Run Keyword If    ${SHELL_PRE_CMD}==${1}    BuiltIn.Run Keyword And Continue On Failure    SHELL PRECONDITION
    BuiltIn.Run Keyword And Continue On Failure    PREPROCESSING
    BuiltIn.Run Keyword If    ${SCENARIO_EXECUTION}==${1}    BuiltIn.Run Keyword And Continue On Failure    RUN MGTS State Machine
    BuiltIn.Run Keyword If    ${test_file_length}!=${0}    BuiltIn.Run Keyword If    ${DB_Validation}==${1}    BuiltIn.Run Keyword If    ${ON_CALL_DB_Validation}==${1}    BuiltIn.Run Keyword And Continue On Failure    ONCALLDBCONDITION
    ${shelloncall_status}=    BuiltIn.Run Keyword If    ${test_file_length}!=${0}    BuiltIn.Run Keyword If    ${SHELL_COMMAND_VALIDATION}==${1}    BuiltIn.Run Keyword If    ${SHELL_ON_CALL_CMD}==${1}    BuiltIn.Run Keyword And Continue On Failure    SHELL ON CALL CONDITION
    BuiltIn.Run Keyword If    ${SCENARIO_EXECUTION}==${1}    BuiltIn.Run Keyword And Continue On Failure    Verify MGTS State Machine
    ${SCEN_RESULT}    ${mgts_fail}=    BuiltIn.Run Keyword If    ${SCENARIO_EXECUTION}==${1}    BuiltIn.Run Keyword And Continue On Failure    MGTS State Machine PASS FAIL SET
    BuiltIn.Run Keyword If    ${SCENARIO_EXECUTION}==${1}    BuiltIn.Run Keyword And Continue On Failure    MGTS State Machine STOP
    ${autostop_status}=    BuiltIn.Run Keyword If    ${LOGGER_Validation}==${1}    BuiltIn.Run Keyword And Continue On Failure    LOGGER
    ${shellpost_status}=    BuiltIn.Run Keyword If    ${test_file_length}!=${0}    BuiltIn.Run Keyword If    ${SHELL_COMMAND_VALIDATION}==${1}    BuiltIn.Run Keyword If    ${SHELL_POST_CMD}==${1}    BuiltIn.Run Keyword And Continue On Failure    SHELL POST CONDITION
    ${pcap_status}=        BuiltIn.Run Keyword If    ${test_file_length}!=${0}    BuiltIn.Run Keyword If    ${PCAP_Validation}==${1}    BuiltIn.Run Keyword And Continue On Failure    EXECUTE PCAP
    ${cdr_status}=    BuiltIn.Run Keyword If    ${test_file_length}!=${0}    BuiltIn.Run Keyword If    ${CDR_Validation}==${1}    BuiltIn.Run Keyword And Continue On Failure    CDR
    ${postdb_status}=    BuiltIn.Run Keyword If    ${test_file_length}!=${0}    BuiltIn.Run Keyword If    ${DB_Validation}==${1}    BuiltIn.Run Keyword If    ${POST_DB_QUERY_Validation}==${1}    BuiltIn.Run Keyword And Continue On Failure    POSTCONDITION
    BuiltIn.Run Keyword If    ${SCENARIO_EXECUTION}==${1}    BuiltIn.Run Keyword And Continue On Failure    MGTS LOG COPY
    ${TC_RESULT}=    BuiltIn.Run Keyword And Continue On Failure    Set Variable If    '${SCEN_RESULT}'in['True','1','None'] and '${cdr_status}'in['PASS','NONE','None'] and '${pcap_status}'in['PASS','NONE','None'] and '${autostop_status}'in['PASS','NONE','None'] and '${postdb_status}'in['PASS','NONE','None']    PASS    FAIL
    ${SCENARIO_RESULT}=    BuiltIn.Run Keyword And Continue On Failure    Set Variable If    '${SCEN_RESULT}'in['True','1','None']    PASS    FAIL
    BuiltIn.Run Keyword If    ${MIGRATION_FLAG}==${2}    BuiltIn.Run Keyword If    '${TC_RESULT}' in['PASS']    Copy File    ${LATEST_REF_PATH}${TEST_NAME}.txt    ${PRE_POST_VALIDATE_PATH}
    [Return]    ${SCENARIO_RESULT}    ${autostop_status}    ${cdr_status}    ${postdb_status}    ${pcap_status}    ${shellpre_status}    ${shelloncall_status}    ${shellpost_status}    ${TC_RESULT}